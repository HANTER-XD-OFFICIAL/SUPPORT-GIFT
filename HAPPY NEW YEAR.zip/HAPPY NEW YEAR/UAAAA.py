import random,string


def Samsung():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    model=random.choice(["GT-I9505","SM-T835","SM-S901U","MMB29K","SM-S134DL","SM-J250F","SM-A217F","SM-A326B","SM-A125F","SM-A720F","SM-A326U","SM-G532M","SM-J410G","SM-A205GN","SM-A205GN","SM-A505GN","SM-G930F","SM-J210F","SM-N9005","SM-J210F"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    ua=f"Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/LRX22C) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.15.89;FBPN/"+platform+";FBLC/sv_SE;FBBV/"+vir+";FBCR/S COMVIQ;FBMF/samsung;FBBD/samsung;FBDV/"+model+";FBSV/5.0.1;FBCA/armeabi-v7a:armeabi;FBDM/{density="+str(random.choice(range(1,4)))+".0,width="+str(random.choice(range(720,1500)))+",height="+str(random.choice(range(1500,2000)))+"};FB_FW/1;]"
    return ua


def Redmi():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    model=random.choice(["M2103K19G","Redmi Note 8T","Redmi Note 7","Redmi Note 8T","M2006C3MNG"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/RKQ1.201004.002) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.32.117;FBPN/"+platform+";FBLC/cs_CZ;FBBV/"+vir+";FBCR/O2.CZ;FBMF/Xiaomi;FBBD/xiaomi;FBDV/"+model+";FBSV/11;FBCA/arm64-v8a:null;FBDM/{density="+str(random.choice(range(1,4)))+".0,width="+str(random.choice(range(720,1500)))+",height="+str(random.choice(range(1500,2000)))+"};FB_FW/1;] FBBK/1"
    return ua


def zte():
    model=random.choice(["Z987","Z6356T","Z6356T"])
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/RP1A.201005.001) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.35.115;FBPN/"+platform+";FBLC/en_AU;FBBV/"+vir+";FBCR/Telstra;FBMF/ZTE;FBBD/ZTE;FBDV/"+model+";FBSV/11;FBCA/arm64-v8a:null;FBDM/{density="+str(random.choice(range(1,4)))+".0,width="+str(random.choice(range(720,1500)))+",height="+str(random.choice(range(1500,2000)))+"};FB_FW/1;]"
    return ua


def oppo():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    CPH="CPH"+str(random.choice(range(1000,2000)))
    model=random.choice([CPH,"oppo r7sm","F1w Build","Leelbox"])
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/O11019) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.33.111;FBPN/"+platform+";FBLC/km_KH;FBBV/"+vir+";FBCR/Metfone;FBMF/OPPO;FBBD/OPPO;FBDV/"+model+";FBSV/8.1.0;FBCA/armeabi-v7a:armeabi;FBDM/{density="+str(random.choice(range(1,4)))+".0,width="+str(random.choice(range(720,1500)))+",height="+str(random.choice(range(1500,2000)))+"};FB_FW/1;FBRV/396611140;]"
    return ua


def HUAWEI():
    model=random.choice(["DUB-LX1","AGS2-L09","POT-LX1","DRA-LX2","POT-LX3","VOG-L29","EVR-N29","FIG-LX1","Kirin Treble","HUAWEI LUA-L21","ATU-L31","COL-L29","NAM-LX9","VOG-L29","JKM-LX1","RNE-L22"])
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/HUAWEILUA-L21) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.1.116;FBPN/"+platform+";FBLC/cs_CZ;FBBV/"+vir+";FBCR/O2-CZ;FBMF/HUAWEI;FBBD/HUAWEI;FBDV/"+model+";FBSV/5.1;FBCA/armeabi-v7a:armeabi;FBDM/{density="+str(random.choice(range(1,4)))+".0,width="+str(random.choice(range(720,1500)))+",height="+str(random.choice(range(1500,2000)))+"};]"
    return ua


def lge():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    model=random.choice(["LML713DL","E6653","LM-X420","LGL355DL","LG-H901","LM-Q610.FG","D6503"])
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/OPM1.171019.019) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.16.236;FBPN/"+platform+";FBLC/en_US;FBBV/"+vir+";FBCR/null;FBMF/LGE;FBBD/lge;FBDV/"+model+";FBSV/8.1.0;FBCA/armeabi-v7a:armeabi;FBDM/{density="+str(random.choice(range(1,4)))+".625,width="+waid+",height="+hight+"};FB_FW/1;]"
    return ua


def Hisense():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; Hisense Hi  3 Build/NRD9OM) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.39.118;FBPN/ "+platform+";FBLC/es_MX;FBBV/ "+vir+";FBCR/TELCEL;FBMF/Hisense;FBBD/ Hisense;FBDV/Hisense Hi 3;FBSV/7.0;FBCA/armeabi- v7a:armeabi;FBDM/ {density="+str(random.choice(range(1,4)))+".0,width="+waid+"height="+hight+"};FB_FW/1;FBRV/181817659;] FBBK/1"
    return ua


def vivo():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    model=random.choice(["vivo 1935","V3Max"])
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/QP1A.190711.020) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.8.106;FBPN/"+platform+";FBLC/in_ID;FBBV/"+vir+";FBCR/AXIS;FBMF/vivo;FBBD/vivo;FBDV/"+model+";FBSV/10;FBCA/arm64-v8a:null;FBDM/{density="+str(random.choice(range(1,4)))+".29375,width="+waid+",height="+hight+"};]"
    return ua


def Amazon():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; KFMUWI Build/NS6315) [FBAN/"+FBAN+";FBAV/"+cho+".1.0.9.122;FBPN/"+platform+";FBLC/en_US;FBBV/"+vir+";FBCR/null;FBMF/Amazon;FBBD/Amazon;FBDV/KFMUWI;FBSV/7.1.2;FBCA/armeabi-v7a:armeabi;FBDM/{density="+str(random.choice(range(1,4)))+".0,width="+waid+",height="+hight+"};FB_FW/1;]"
    return ua


def google():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    model=random.choice(["Pixel 6a","Pixel 3"])
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/QQ3A.200605.001) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.11.120;FBPN/"+platform+";FBLC/en_US;FBBV/"+vir+";FBCR/Verizon;FBMF/Google;FBBD/google;FBDV/"+model+";FBSV/10;FBCA/arm64-v8a:null;FBDM/{density="+str(random.choice(range(1,4)))+".75,width="+waid+",height="+hight+"};FB_FW/1;] FBBK/1"
    return ua


def motorola():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    model=random.choice(["moto e5 plus","moto g(20)","moto e","NX55 Build","moto e(7i) power","moto e(7) plus","moto g go","moto g play - 2023","moto e6","moto g power (2021)","Moto"])
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/RTAS31.68-20-2) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.13.142;FBPN/"+platform+";FBLC/es_US;FBBV/"+vir+";FBCR/TELCEL;FBMF/motorola;FBBD/motorola;FBDV/"+model+";FBSV/11;FBCA/arm64-v8a:null;FBDM/{density="+str(random.choice(range(1,4)))+".75,width="+waid+",height="+hight+"};FB_FW/1;]"
    return ua


def lenovo():
    model=random.choice(["Lenovo TB-X505F","Lenovo A6020a46"])
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/QKQ1.191224.003) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.9.116;FBPN/"+platform+";FBLC/en_GB;FBBV/"+vir+";FBCR/null;FBMF/LENOVO;FBBD/Lenovo;FBDV/"+model+";FBSV/10;FBCA/arm64-v8a:null;FBDM/{density="+str(random.choice(range(1,4)))+".0,width="+waid+",height="+hight+"};FB_FW/1;]"
    return ua



def asus():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    densy=str(random.choice(range(1,4)))
    model=random.choice(["ASUS_Z01QD","ASUS_I005DC","NX55","MXB48T"])
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; "+model+" Build/N2G48H) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.33.111;FBPN/"+platform+";FBLC/zh_CN;FBBV/"+vir+";FBCR/EE;FBMF/Asus;FBBD/Asus;FBDV/"+model+";FBSV/7.1.2;FBCA/x86:armeabi-v7a;FBDM/{density="+densy+".0,width="+waid+",height="+hight+"};FB_FW/1;FBRV/0;]"
    return ua


def poko():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    densy=str(random.choice(range(1,4)))
    ua="Dalvik/2.1.0 (Linux; Android "+Anderson+"; POCOPHONE F1) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.28.115;FBBV/"+vir+";FBRV/0;FBPN/"+platform+";FBLC/en_US;FBMF/POCOPHONE;FBBF/Poco;FBDV/Poco F1;FBSV/10;FBCA/arm64-v8a:armeabi-v7a:armeabi;FBDM/{density="+densy+".0,width="+waid+",height="+hight+"};FB_FW/1;]"
    return ua


def tecno():
    Anderson=random.choice(["10","13","7.0.0","7.1.1","9","12","11","9.0","8.0.0","7.1.2","7.0","4","5","4.4.2","5.1.1","6.0.1","9.0.1"])
    fb=random.choice(["com.facebook.adsmanager|MobileAdsManagerAndroid","com.facebook.katana|FB4A","com.facebook.orca|Orca-Android","com.facebook.mlite|MessengerLite"])
    FBAN=fb.split("|")[1]
    platform=fb.split("|")[0]
    vir=str(random.choice(range(111111111,999999999)))
    cho=str(random.choice(range(43,447)))
    waid=str(random.choice(range(720,1500)))
    hight=str(random.choice(range(1500,2000)))
    densy=str(random.choice(range(1,4)))
    ua="Dalvik/2.1.0 (Linux; U; Android "+Anderson+"; TECNO KI5k Build/SP1A.210812.016) [FBAN/"+FBAN+";FBAV/"+cho+".0.0.13.101;FBPN/"+platform+";FBLC/en_US;FBBV/"+vir+";FBCR/LoneStar;FBMF/TECNO;FBBD/TECNO;FBDV/TECNO KI5k;FBSV/12;FBCA/armeabi-v7a:armeabi;FBDM/{density="+densy+".0,width="+waid+",height="+hight+"};FB_FW/1;]"
    return ua











