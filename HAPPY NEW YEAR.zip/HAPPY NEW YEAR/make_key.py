
key=input("Input key:")
ky=key.split('\'')[1]
print(ky[5:15])